package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.ui.navigation.AppNavigationShell
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Enabling full edge-to-edge support for notch and gesture space padding
        enableEdgeToEdge()
        
        setContent {
            MyApplicationTheme {
                AppNavigationShell()
            }
        }
    }
}
