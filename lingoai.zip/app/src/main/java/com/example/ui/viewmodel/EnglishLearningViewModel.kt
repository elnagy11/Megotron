package com.example.ui.viewmodel

import android.app.Application
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.dao.ProgressDao
import com.example.data.database.AppDatabase
import com.example.data.model.ChatMessage
import com.example.data.model.LessonStory
import com.example.data.model.SavedWord
import com.example.data.model.UserProgress
import com.example.data.network.GeminiRetrofitClient
import com.example.data.repository.EnglishLearningRepository
import com.example.util.AndroidSpeechRecognizer
import com.example.util.AndroidTtsEngine
import com.squareup.moshi.Moshi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class EnglishLearningViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getDatabase(application)
    private val repository = EnglishLearningRepository(
        db.wordDao(),
        db.chatDao(),
        db.storyDao(),
        db.progressDao()
    )

    private val ttsEngine = AndroidTtsEngine(application)
    private var speechRecognizer: AndroidSpeechRecognizer? = null

    // --- System UI Settings States ---
    var difficultyLevel by mutableStateOf("Intermediate")
    var nativeLanguage by mutableStateOf("Spanish")
    var tutorPersona by mutableStateOf("Friendly Coach")
    var voiceSpeed by mutableStateOf(1.0f)
    var useFemaleVoice by mutableStateOf(true)
    var isTtsEnabled by mutableStateOf(true)
    var enablePronunciationCheck by mutableStateOf(true)

    // --- Chat & Voice Session UI States ---
    var chatMessageInput by mutableStateOf("")
    var isAiGenerating by mutableStateOf(false)
    var isRecordingVoIP by mutableStateOf(false)
    var voiceTimerSeconds by mutableStateOf(0)
    private var voiceTimerJob: kotlinx.coroutines.Job? = null

    // Stt/Tts Realtime states
    var liveTranscriptionSubtitle by mutableStateOf("")
    var micResponseAmplitude by mutableStateOf(0f)

    // --- Saved Word UI States ---
    var wordSearchQuery by mutableStateOf("")
    var wordFilterCategory by mutableStateOf("All")
    var wordFilterTab by mutableStateOf("All") // "All" | "Favorites" | "Learned"
    var activeFlashcardIndex by mutableStateOf(0)
    var isFlashcardFlipped by mutableStateOf(false)

    // --- Story Screen UI States ---
    var selectedStory by mutableStateOf<LessonStory?>(null)
    var isReadingModeActive by mutableStateOf(false)
    var isStoryTtsSpeaking by mutableStateOf(false)
    var selectedQuestionsAnswers by mutableStateOf<Map<Int, Int>>(emptyMap()) // map of index -> selected index
    var showQuizResults by mutableStateOf(false)
    var translationRevealedIndex by mutableStateOf(-1) // -1 or index of paragraphs

    // --- Exposed Observables from Repository ---
    val chatHistory: StateFlow<List<ChatMessage>> = repository.chatHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val savedWordsList: StateFlow<List<SavedWord>> = repository.allWords
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val lessonsStoriesList: StateFlow<List<LessonStory>> = repository.stories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userLearningStats: StateFlow<UserProgress?> = repository.userProgress
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    init {
        viewModelScope.launch {
            repository.initializeProgress()
            repository.prepopulateStoriesIfEmpty()
            repository.updateStreak()
        }
        setupSpeechEngine()
    }

    private fun setupSpeechEngine() {
        speechRecognizer = AndroidSpeechRecognizer(
            context = getApplication(),
            onResult = { finalTranscript ->
                liveTranscriptionSubtitle = finalTranscript
                chatMessageInput = finalTranscript
                micResponseAmplitude = 0f
                if (isRecordingVoIP) {
                    stopVoipRecordingAndSend()
                }
            },
            onPartialResult = { partial ->
                liveTranscriptionSubtitle = partial
            },
            onError = { errorMsg ->
                isRecordingVoIP = false
                micResponseAmplitude = 0f
                stopVoiceTimer()
                Toast.makeText(getApplication(), errorMsg, Toast.LENGTH_SHORT).show()
            },
            onRmsChanged = { rms ->
                // Scale RMS feedback to nicer percentage float
                micResponseAmplitude = ((rms + 2.0f) / 10.0f).coerceIn(0f, 1f)
            }
        )
    }

    // --- Message Controllers ---
    fun runTextInputSubmit() {
        val prompt = chatMessageInput.trim()
        if (prompt.isEmpty()) return
        
        chatMessageInput = ""
        liveTranscriptionSubtitle = ""
        isAiGenerating = true
        
        viewModelScope.launch {
            val result = repository.sendUserMessageAndGetCorrection(
                userText = prompt,
                isVoice = false,
                difficulty = difficultyLevel,
                nativeLanguage = nativeLanguage,
                tutorPersona = tutorPersona
            )
            
            isAiGenerating = false
            result.onSuccess { report ->
                if (isTtsEnabled) {
                    ttsEngine.speak(report.reply)
                }
            }
        }
    }

    // --- VolP / Voice Action Controllers ---
    fun startVoipVoiceRecording() {
        ttsEngine.stop()
        isReadingModeActive = false
        isStoryTtsSpeaking = false
        liveTranscriptionSubtitle = "Listening..."
        isRecordingVoIP = true
        voiceTimerSeconds = 0
        micResponseAmplitude = 0.1f
        
        startVoiceTimer()
        speechRecognizer?.startListening()
    }

    fun stopVoipRecordingAndSend() {
        isRecordingVoIP = false
        stopVoiceTimer()
        speechRecognizer?.stopListening()
        
        val transcript = liveTranscriptionSubtitle.trim()
        if (transcript.isEmpty() || transcript == "Listening...") {
            Toast.makeText(getApplication(), "No speech captured. Try again!", Toast.LENGTH_SHORT).show()
            return
        }

        isAiGenerating = true
        val duration = voiceTimerSeconds
        viewModelScope.launch {
            val result = repository.sendUserMessageAndGetCorrection(
                userText = transcript,
                isVoice = true,
                difficulty = difficultyLevel,
                nativeLanguage = nativeLanguage,
                tutorPersona = tutorPersona,
                voiceDurationSeconds = duration
            )
            isAiGenerating = false
            result.onSuccess { report ->
                ttsEngine.speak(report.reply)
            }
        }
    }

    private fun startVoiceTimer() {
        voiceTimerJob?.cancel()
        voiceTimerJob = viewModelScope.launch {
            while (isRecordingVoIP) {
                kotlinx.coroutines.delay(1000)
                voiceTimerSeconds++
            }
        }
    }

    private fun stopVoiceTimer() {
        voiceTimerJob?.cancel()
        voiceTimerJob = null
    }

    // --- Saved Word Actions ---
    fun saveNewWord(word: String, meaning: String, example: String, category: String) {
        viewModelScope.launch {
            val exists = repository.isWordSaved(word)
            if (exists) {
                Toast.makeText(getApplication(), "'$word' is already preserved in vault", Toast.LENGTH_SHORT).show()
                return@launch
            }
            val newWord = SavedWord(
                word = word.trim(),
                meaning = meaning.trim(),
                example = example.trim(),
                category = category
            )
            repository.saveWord(newWord)
            repository.addXpPoints(10) // reward for learning words!
            Toast.makeText(getApplication(), "Saved to Word Vault! +10 XP", Toast.LENGTH_SHORT).show()
        }
    }

    fun deleteWordFromVault(savedWord: SavedWord) {
        viewModelScope.launch {
            repository.deleteWord(savedWord)
            Toast.makeText(getApplication(), "Word removed.", Toast.LENGTH_SHORT).show()
        }
    }

    fun toggleWordFavorite(savedWord: SavedWord) {
        viewModelScope.launch {
            repository.toggleFavoriteWord(savedWord)
        }
    }

    fun toggleWordLearned(savedWord: SavedWord) {
        viewModelScope.launch {
            repository.toggleLearnedWord(savedWord)
        }
    }

    fun clearChatHistory() {
        viewModelScope.launch {
            repository.clearChatHistory()
            Toast.makeText(getApplication(), "Chat history cleared", Toast.LENGTH_SHORT).show()
        }
    }

    // --- Story Interaction Actions ---
    fun selectActiveStory(story: LessonStory) {
        selectedStory = story
        isReadingModeActive = true
        selectedQuestionsAnswers = emptyMap()
        showQuizResults = false
        translationRevealedIndex = -1
        stopStoryAudioNarration()
    }

    fun speakStoryAudioNarration(content: String) {
        isStoryTtsSpeaking = true
        ttsEngine.speak(content)
    }

    fun stopStoryAudioNarration() {
        isStoryTtsSpeaking = false
        ttsEngine.stop()
    }

    fun submitStoryQuizAnswers() {
        showQuizResults = true
        val story = selectedStory ?: return
        
        // Count correct answers
        val moshi = GeminiRetrofitClient.moshiInstance
        val type = com.squareup.moshi.Types.newParameterizedType(List::class.java, QuizQuestion::class.java)
        val adapter = moshi.adapter<List<QuizQuestion>>(type)
        val questions: List<QuizQuestion> = try {
            adapter.fromJson(story.quizJson) ?: emptyList()
        } catch (e: java.lang.Exception) {
            emptyList()
        }

        var correctCount = 0
        questions.forEachIndexed { i, q ->
            if (selectedQuestionsAnswers[i] == q.answer) {
                correctCount++
            }
        }

        if (correctCount == questions.size) {
            viewModelScope.launch {
                repository.completeStory(story)
                Toast.makeText(getApplication(), "Amazing! You achieved 100% on the quiz! +50 XP", Toast.LENGTH_LONG).show()
            }
        } else {
            Toast.makeText(getApplication(), "Completed quiz! Keep practicing to get 100%.", Toast.LENGTH_SHORT).show()
        }
    }

    // --- Settings Configuration Toggles ---
    fun updateVoiceConfig(female: Boolean, speed: Float) {
        useFemaleVoice = female
        voiceSpeed = speed
        ttsEngine.setVoiceType(female)
        ttsEngine.setSpeed(speed)
    }

    fun speakSpecificText(text: String) {
        ttsEngine.speak(text)
    }

    override fun onCleared() {
        super.onCleared()
        ttsEngine.shutdown()
        speechRecognizer?.destroy()
    }
}

/**
 * Story Quiz Helper classes
 */
@com.squareup.moshi.JsonClass(generateAdapter = true)
data class QuizQuestion(
    val question: String,
    val options: List<String>,
    val answer: Int
)

@com.squareup.moshi.JsonClass(generateAdapter = true)
data class KeyWordItem(
    val word: String,
    val meaning: String
)
