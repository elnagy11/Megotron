package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SavedWord
import com.example.ui.theme.*
import com.example.ui.viewmodel.EnglishLearningViewModel

@Composable
fun WordVaultScreen(viewModel: EnglishLearningViewModel) {
    val wordsState by viewModel.savedWordsList.collectAsState()
    
    // UI states for adding manual words
    var isAddPanelOpen by remember { mutableStateOf(false) }
    var wordInput by remember { mutableStateOf("") }
    var meaningInput by remember { mutableStateOf("") }
    var exampleInput by remember { mutableStateOf("") }
    var categorySelection by remember { mutableStateOf("General") }

    // Navigation sub-state for Flashcard Mode
    var isFlashcardsModeActive by remember { mutableStateOf(false) }

    // Filtering lists
    val filteredWordsList = wordsState.filter { item ->
        val matchesSearch = item.word.contains(viewModel.wordSearchQuery.trim(), ignoreCase = true) ||
                item.meaning.contains(viewModel.wordSearchQuery.trim(), ignoreCase = true)
        
        val matchesCategory = viewModel.wordFilterCategory == "All" || item.category == viewModel.wordFilterCategory
        
        val matchesTab = when (viewModel.wordFilterTab) {
            "Favorites" -> item.isFavorite
            "Learned" -> item.isLearned
            else -> true
        }

        matchesSearch && matchesCategory && matchesTab
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MidnightBg)
            .statusBarsPadding()
            .padding(horizontal = 16.dp)
    ) {
        if (isFlashcardsModeActive) {
            // Flashcard Carousel Mode
            FlashcardCarouselWidget(
                words = filteredWordsList,
                activeCardIndex = viewModel.activeFlashcardIndex,
                isFlipped = viewModel.isFlashcardFlipped,
                onCardClicked = { viewModel.isFlashcardFlipped = !viewModel.isFlashcardFlipped },
                onNextCard = {
                    if (viewModel.activeFlashcardIndex < filteredWordsList.lastIndex) {
                        viewModel.activeFlashcardIndex++
                        viewModel.isFlashcardFlipped = false
                    }
                },
                onPreviousCard = {
                    if (viewModel.activeFlashcardIndex > 0) {
                        viewModel.activeFlashcardIndex--
                        viewModel.isFlashcardFlipped = false
                    }
                },
                onToggleLearned = { savedWord ->
                    viewModel.toggleWordLearned(savedWord)
                },
                onExitFlashcards = {
                    isFlashcardsModeActive = false
                    viewModel.isFlashcardFlipped = false
                }
            )
        } else {
            // Standard Word Vault List Mode
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 76.dp) // Bottom padding for navigation rails
            ) {
                Spacer(modifier = Modifier.height(16.dp))

                // Vault Header Controls
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "My Word Vault",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "${filteredWordsList.size} vocabulary cards registered",
                            fontSize = 12.sp,
                            color = TextSecondary,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }

                    Row {
                        IconButton(
                            onClick = { isAddPanelOpen = !isAddPanelOpen },
                            modifier = Modifier
                                .background(MidnightSurfaceElevated, CircleShape)
                                .testTag("toggle_add_word_panel_btn")
                        ) {
                            Icon(
                                imageVector = if (isAddPanelOpen) Icons.Default.Close else Icons.Default.Add,
                                contentDescription = "Add Word",
                                tint = ElectricTeal
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Interactive search query bar
                OutlinedTextField(
                    value = viewModel.wordSearchQuery,
                    onValueChange = { viewModel.wordSearchQuery = it },
                    placeholder = { Text("Search vocabulary prefix...", fontSize = 14.sp) },
                    leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = TextSecondary) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricTeal,
                        unfocusedBorderColor = MidnightSurface,
                        focusedContainerColor = MidnightSurface,
                        unfocusedContainerColor = MidnightSurface,
                        errorContainerColor = MidnightSurface
                    ),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("vocabulary_search_query_bar"),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Custom Categories Carousel Slider
                val categories = listOf("All", "General", "Travel", "Business", "Academic", "Idioms")
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(categories) { cat ->
                        FilterChip(
                            selected = viewModel.wordFilterCategory == cat,
                            onClick = { viewModel.wordFilterCategory = cat },
                            label = { Text(cat, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = ElectricTeal,
                                selectedLabelColor = MidnightBg,
                                containerColor = MidnightSurface,
                                labelColor = TextSecondary
                            ),
                            border = null
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Tab selectors: "All" | "Favorites" | "Learned"
                TabRow(
                    selectedTabIndex = when (viewModel.wordFilterTab) {
                        "Favorites" -> 1
                        "Learned" -> 2
                        else -> 0
                    },
                    containerColor = Color.Transparent,
                    contentColor = ElectricTeal,
                    divider = {},
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            color = ElectricTeal,
                            modifier = Modifier.tabIndicatorOffset(tabPositions[when (viewModel.wordFilterTab) {
                                "Favorites" -> 1
                                "Learned" -> 2
                                else -> 0
                            }])
                        )
                    }
                ) {
                    Tab(
                        selected = viewModel.wordFilterTab == "All",
                        onClick = { viewModel.wordFilterTab = "All" },
                        text = { Text("All", fontSize = 13.sp) }
                    )
                    Tab(
                        selected = viewModel.wordFilterTab == "Favorites",
                        onClick = { viewModel.wordFilterTab = "Favorites" },
                        text = { Text("Favorites", fontSize = 13.sp) }
                    )
                    Tab(
                        selected = viewModel.wordFilterTab == "Learned",
                        onClick = { viewModel.wordFilterTab = "Learned" },
                        text = { Text("Learned", fontSize = 13.sp) }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Dynamic Action: Collapsible panel to add manual words
                AnimatedVisibility(visible = isAddPanelOpen) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MidnightSurfaceElevated),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "Preserve Manual Word",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.height(10.dp))

                            OutlinedTextField(
                                value = wordInput,
                                onValueChange = { wordInput = it },
                                label = { Text("English Word") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("add_word_text_input"),
                                singleLine = true
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = meaningInput,
                                onValueChange = { meaningInput = it },
                                label = { Text("Meaning / Definition") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("add_meaning_text_input"),
                                singleLine = true
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = exampleInput,
                                onValueChange = { exampleInput = it },
                                label = { Text("Example Sentence") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("add_example_text_input"),
                                singleLine = true
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // Small category selection row
                            Text("Category:", fontSize = 11.sp, color = TextSecondary)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                val miniCats = listOf("General", "Travel", "Business", "Idioms")
                                miniCats.forEach { mc ->
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (categorySelection == mc) ElectricTeal else MidnightSurface)
                                            .clickable { categorySelection = mc }
                                            .padding(horizontal = 10.dp, vertical = 6.dp)
                                    ) {
                                        Text(
                                            text = mc,
                                            fontSize = 11.sp,
                                            color = if (categorySelection == mc) MidnightBg else TextSecondary,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            Button(
                                onClick = {
                                    if (wordInput.isNotBlank() && meaningInput.isNotBlank()) {
                                        viewModel.saveNewWord(
                                            word = wordInput,
                                            meaning = meaningInput,
                                            example = exampleInput,
                                            category = categorySelection
                                        )
                                        // Reset inputs
                                        wordInput = ""
                                        meaningInput = ""
                                        exampleInput = ""
                                        isAddPanelOpen = false
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = ElectricTeal),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("save_word_submit_btn")
                            ) {
                                Text("Add to Vault", color = MidnightBg, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // If lists are populated, offer Flashcard Entry Point Banner!
                if (filteredWordsList.size >= 2) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = NeonBlue.copy(alpha = 0.15f)),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp)
                            .clickable {
                                viewModel.activeFlashcardIndex = 0
                                viewModel.isFlashcardFlipped = false
                                isFlashcardsModeActive = true
                            }
                            .testTag("start_flashcards_btn")
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .background(NeonBlue.copy(alpha = 0.2f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Style,
                                    contentDescription = null,
                                    tint = ElectricTeal,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Start Flashcards Study",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "Review these ${filteredWordsList.size} cards with custom cards layout",
                                    fontSize = 11.sp,
                                    color = TextSecondary
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = ElectricTeal
                            )
                        }
                    }
                }

                // Main Vocabulary List
                if (filteredWordsList.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.AllInbox,
                                contentDescription = null,
                                tint = TextSecondary.copy(alpha = 0.3f),
                                modifier = Modifier.size(54.dp)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "Empty Vault List",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "Terms you search or filter aren't present. Type details above to manual record, or long-press on chat words to preserve vocabulary instantly!",
                                fontSize = 13.sp,
                                color = TextSecondary,
                                textAlign = TextAlign.Center,
                                lineHeight = 18.sp,
                                modifier = Modifier.padding(start = 24.dp, end = 24.dp, top = 4.dp, bottom = 0.dp)
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(filteredWordsList) { item ->
                            SavedVocabularyItemRow(
                                item = item,
                                viewModel = viewModel
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SavedVocabularyItemRow(
    item: SavedWord,
    viewModel: EnglishLearningViewModel
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MidnightSurface),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("saved_word_card_${item.word.lowercase()}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { viewModel.toggleWordLearned(item) }
                    ) {
                        Icon(
                            imageVector = if (item.isLearned) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                            contentDescription = "Toggle Learned",
                            tint = if (item.isLearned) SoftEmerald else TextSecondary,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    Column {
                        Text(
                            text = item.word,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (item.isLearned) TextSecondary else TextPrimary
                        )
                        Text(
                            text = item.category,
                            fontSize = 10.sp,
                            color = ElectricTeal,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Row {
                    IconButton(onClick = { viewModel.toggleWordFavorite(item) }) {
                        Icon(
                            imageVector = if (item.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Toggle favorite",
                            tint = if (item.isFavorite) SoftCoral else TextSecondary
                        )
                    }

                    IconButton(onClick = { viewModel.deleteWordFromVault(item) }) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete from vault",
                            tint = TextSecondary.copy(alpha = 0.5f)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Meaning Details
            Text(
                text = "Meaning: ${item.meaning}",
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                color = TextPrimary,
                modifier = Modifier.padding(start = 12.dp)
            )

            if (item.example.isNotEmpty()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Example: \"${item.example}\"",
                    fontSize = 12.sp,
                    color = TextSecondary,
                    fontStyle = FontStyle.Italic,
                    modifier = Modifier.padding(start = 12.dp)
                )
            }
        }
    }
}

@Composable
fun FlashcardCarouselWidget(
    words: List<SavedWord>,
    activeCardIndex: Int,
    isFlipped: Boolean,
    onCardClicked: () -> Unit,
    onNextCard: () -> Unit,
    onPreviousCard: () -> Unit,
    onToggleLearned: (SavedWord) -> Unit,
    onExitFlashcards: () -> Unit
) {
    if (words.isEmpty()) return
    val currentWord = words[activeCardIndex]

    // 3D Flip animation interpolations
    val rotation by animateFloatAsState(
        targetValue = if (isFlipped) 180f else 0f,
        animationSpec = tween(durationMillis = 400, easing = FastOutSlowInEasing),
        label = "CardRotation"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Exit Panel Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onExitFlashcards,
                modifier = Modifier
                    .background(MidnightSurface, CircleShape)
                    .testTag("exit_flashcards_btn")
            ) {
                Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
            }

            Text(
                text = "Flashcard ${activeCardIndex + 1} of ${words.size}",
                fontSize = 15.sp,
                color = TextPrimary,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.width(48.dp))
        }

        // Active 3D Flippable Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(340.dp)
                .graphicsLayer {
                    rotationY = rotation
                    cameraDistance = 8 * density
                }
                .clickable { onCardClicked() }
                .clip(RoundedCornerShape(24.dp))
                .background(MidnightSurface)
                .testTag("flippable_vocab_flashcard"),
            contentAlignment = Alignment.Center
        ) {
            // Draw card layout based on flip ratio
            if (rotation <= 90f) {
                // Front View: Displays English Word and play trigger icon
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier.padding(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Style,
                        contentDescription = null,
                        tint = ElectricTeal.copy(alpha = 0.5f),
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    Text(
                        text = currentWord.word,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Category: ${currentWord.category}",
                        fontSize = 12.sp,
                        color = ElectricTeal,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(28.dp))
                    Text(
                        text = "Tap Card to Reveal Meaning",
                        fontSize = 12.sp,
                        color = TextSecondary,
                        fontStyle = FontStyle.Italic
                    )
                }
            } else {
                // Back View: Renders definition details, flipped 180 deg
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier
                        .graphicsLayer { rotationY = 180f }
                        .padding(24.dp)
                ) {
                    Text(
                        text = "Definition",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = ElectricTeal,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = currentWord.meaning,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary,
                        textAlign = TextAlign.Center,
                        lineHeight = 24.sp
                    )

                    if (currentWord.example.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(20.dp))
                        Text(
                            text = "Usage Example:",
                            fontSize = 11.sp,
                            color = TextSecondary,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "\"${currentWord.example}\"",
                            fontSize = 14.sp,
                            color = TextSecondary,
                            fontStyle = FontStyle.Italic,
                            textAlign = TextAlign.Center,
                            lineHeight = 18.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    // Mark Learned inside Flashcard directly
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(MidnightSurfaceElevated)
                            .clickable { onToggleLearned(currentWord) }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Icon(
                            imageVector = if (currentWord.isLearned) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                            contentDescription = null,
                            tint = if (currentWord.isLearned) SoftEmerald else TextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (currentWord.isLearned) "Marked as Learned" else "Mark as Learned",
                            fontSize = 12.sp,
                            color = TextPrimary,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        // Navigation Arrows and Slide Controller
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            FilledIconButton(
                onClick = onPreviousCard,
                enabled = activeCardIndex > 0,
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = MidnightSurfaceElevated),
                modifier = Modifier.size(56.dp)
            ) {
                Icon(imageVector = Icons.Default.ChevronLeft, contentDescription = "Previous")
            }

            Text(
                text = "Tap to Flip Card",
                fontSize = 13.sp,
                color = TextSecondary
            )

            FilledIconButton(
                onClick = onNextCard,
                enabled = activeCardIndex < words.lastIndex,
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = MidnightSurfaceElevated),
                modifier = Modifier.size(56.dp)
            ) {
                Icon(imageVector = Icons.Default.ChevronRight, contentDescription = "Next")
            }
        }
    }
}
