package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val MidnightBg = Color(0xFFFEF7FF)
val MidnightSurface = Color(0xFFFFFFFF)
val MidnightSurfaceElevated = Color(0xFFF3EDF7)

val ElectricTeal = Color(0xFF6750A4)
val NeonBlue = Color(0xFF8B6CBF)
val SoftCoral = Color(0xFFBA1A1A)
val SoftEmerald = Color(0xFF15803D)

val TextPrimary = Color(0xFF1C1B1F)
val TextSecondary = Color(0xFF49454F)
val AccentAmber = Color(0xFFFBBF24)

