package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.collectAsState
import com.example.ui.theme.*
import com.example.ui.viewmodel.EnglishLearningViewModel

@Composable
fun VoiceChatScreen(
    viewModel: EnglishLearningViewModel,
    onBackToTextChat: () -> Unit
) {
    val chatHistory by viewModel.chatHistory.collectAsState()
    val lastAiVoiceMessageWithScoring = remember(chatHistory) {
        chatHistory.findLast { it.sender == "ai" && it.pronunciationScoreJson != null }
    }
    val report = remember(lastAiVoiceMessageWithScoring) {
        val json = lastAiVoiceMessageWithScoring?.pronunciationScoreJson
        if (!json.isNullOrEmpty()) {
            try {
                com.example.data.network.GeminiRetrofitClient.moshiInstance
                    .adapter(com.example.data.network.PronunciationReport::class.java)
                    .fromJson(json)
            } catch (e: Exception) {
                null
            }
        } else {
            null
        }
    }

    var isListeningMode = viewModel.isRecordingVoIP
    val amplitude = viewModel.micResponseAmplitude

    // Automatic voice state on start
    LaunchedEffect(Unit) {
        if (!viewModel.isRecordingVoIP && !viewModel.isAiGenerating) {
            viewModel.startVoipVoiceRecording()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(MidnightSurfaceElevated, MidnightBg)
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(20.dp)
    ) {
        // Upper Exit Controls
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = {
                    viewModel.stopVoipRecordingAndSend()
                    onBackToTextChat()
                },
                modifier = Modifier
                    .background(MidnightSurface, CircleShape)
                    .testTag("exit_voice_chat_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Close",
                    tint = TextPrimary
                )
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = MidnightSurfaceElevated),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text(
                    text = "${viewModel.tutorPersona} (VoIP)",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = ElectricTeal,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                )
            }

            // Dummy spacer for balance
            Spacer(modifier = Modifier.width(48.dp))
        }

        // Center Dynamic Core UI: Waveform Canvas and Status Avatar
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(240.dp)
            ) {
                // Interactive Sound pulsing rings via Canvas
                VoicePulsingCanvasRings(amplitude = amplitude, isListening = isListeningMode)

                // Large Avatar Core
                Box(
                    modifier = Modifier
                        .size(120.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                colors = if (viewModel.isAiGenerating) {
                                    listOf(SoftCoral, AccentAmber)
                                } else {
                                    listOf(ElectricTeal, NeonBlue)
                                }
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (viewModel.isAiGenerating) {
                            Icons.Default.CloudSync
                        } else if (isListeningMode) {
                            Icons.Default.RecordVoiceOver
                        } else {
                            Icons.Default.GraphicEq
                        },
                        contentDescription = null,
                        tint = MidnightBg,
                        modifier = Modifier.size(52.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // Running timer duration
            Text(
                text = if (isListeningMode) {
                    val m = viewModel.voiceTimerSeconds / 60
                    val s = viewModel.voiceTimerSeconds % 60
                    val formatS = if (s < 10) "0$s" else "$s"
                    "Recording: $m:$formatS"
                } else if (viewModel.isAiGenerating) {
                    "Analyzing syntax..."
                } else {
                    "Tap Mic to speak"
                },
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                color = if (isListeningMode) SoftCoral else TextSecondary
            )
        }

        // Subtitle Live Transcript Overlay Pane
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .padding(bottom = 90.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(MidnightSurface.copy(alpha = 0.85f))
                    .padding(18.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = if (viewModel.isAiGenerating) "AI Tutor is analyzing your grammar..." else "Live Subtitles",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = ElectricTeal,
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = viewModel.liveTranscriptionSubtitle.ifEmpty { "Start speaking in English to see transcripts live here..." },
                    fontSize = 15.sp,
                    color = TextPrimary,
                    textAlign = TextAlign.Center,
                    lineHeight = 22.sp,
                    modifier = Modifier.testTag("voice_subtitles_text")
                )

                if (report != null) {
                    var isVoiceFeedbackExpanded by remember { mutableStateOf(false) }

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = TextSecondary.copy(alpha = 0.15f), thickness = 1.dp)
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { isVoiceFeedbackExpanded = !isVoiceFeedbackExpanded }
                            .testTag("voice_feedback_trigger"),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Assessment,
                                contentDescription = null,
                                tint = ElectricTeal,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Pronunciation Feedback",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = ElectricTeal
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "${report.overallScore}/100",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (report.overallScore >= 80) ElectricTeal else SoftCoral
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = if (isVoiceFeedbackExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                contentDescription = null,
                                tint = TextSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    AnimatedVisibility(visible = isVoiceFeedbackExpanded) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 8.dp),
                            horizontalAlignment = Alignment.Start
                        ) {
                            // Sub-scores
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Accuracy: ${report.accuracyScore}%", fontSize = 11.sp, color = TextSecondary)
                                Text("Intonation: ${report.intonationScore}%", fontSize = 11.sp, color = TextSecondary)
                                Text("Rhythm: ${report.rhythmScore}%", fontSize = 11.sp, color = TextSecondary)
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Text("Phonemes Highlight:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = ElectricTeal)
                            Text(report.phonemeFeedback, fontSize = 11.sp, color = TextPrimary)

                            Spacer(modifier = Modifier.height(6.dp))

                            Text("Stress Emphasis:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = NeonBlue)
                            Text(report.wordStressFeedback, fontSize = 11.sp, color = TextPrimary)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // Bottom Audio Microphone Toggle buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Secondary listen reply button
                IconButton(
                    onClick = {
                        val history = viewModel.chatHistory.value
                        val lastAi = history.lastOrNull { it.sender == "ai" }
                        if (lastAi != null) {
                            viewModel.speakSpecificText(lastAi.text)
                        }
                    },
                    modifier = Modifier
                        .size(50.dp)
                        .background(MidnightSurfaceElevated, CircleShape)
                        .testTag("voice_replay_last_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.VolumeUp,
                        contentDescription = "Replay Last Response",
                        tint = ElectricTeal
                    )
                }

                Spacer(modifier = Modifier.width(36.dp))

                // Primary Mic Action Toggle
                Box(
                    modifier = Modifier
                        .size(76.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                colors = if (isListeningMode) {
                                    listOf(SoftCoral, Color(0xFFFF8585))
                                } else {
                                    listOf(ElectricTeal, NeonBlue)
                                }
                            )
                        )
                        .clickable {
                            if (isListeningMode) {
                                viewModel.stopVoipRecordingAndSend()
                            } else {
                                viewModel.startVoipVoiceRecording()
                            }
                        }
                        .testTag("voice_record_toggle_btn"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isListeningMode) Icons.Default.Stop else Icons.Default.Mic,
                        contentDescription = "Toggle Recording",
                        tint = MidnightBg,
                        modifier = Modifier.size(34.dp)
                    )
                }

                Spacer(modifier = Modifier.width(36.dp))

                // Settings toggle for gender inside VoIP session
                IconButton(
                    onClick = {
                        viewModel.updateVoiceConfig(
                            female = !viewModel.useFemaleVoice,
                            speed = viewModel.voiceSpeed
                        )
                    },
                    modifier = Modifier
                        .size(50.dp)
                        .background(MidnightSurfaceElevated, CircleShape)
                        .testTag("voice_toggle_gender_btn")
                ) {
                    Icon(
                        imageVector = if (viewModel.useFemaleVoice) Icons.Default.Female else Icons.Default.Male,
                        contentDescription = "Toggle Voice Gender",
                        tint = ElectricTeal
                    )
                }
            }
        }
    }
}

@Composable
fun VoicePulsingCanvasRings(amplitude: Float, isListening: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "VoicePulse")
    
    // Animate a pulsing scale ring
    val animatedPulse by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.35f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "PulseScale"
    )

    val animatedAlpha by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 0.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "PulseAlpha"
    )

    Canvas(modifier = Modifier.fillMaxSize()) {
        val center = center
        val baseRadius = 60.dp.toPx()
        val ampBonus = amplitude * 36.dp.toPx()

        // Ring 1: Wave pulse loop
        if (isListening) {
            drawCircle(
                color = ElectricTeal.copy(alpha = animatedAlpha),
                radius = (baseRadius + ampBonus) * animatedPulse,
                style = Stroke(width = 3.dp.toPx())
            )
        }

        // Ring 2: Static outline
        drawCircle(
            color = if (isListening) ElectricTeal.copy(alpha = 0.25f) else TextSecondary.copy(alpha = 0.1f),
            radius = baseRadius + ampBonus,
            style = Stroke(width = 2.dp.toPx())
        )

        // Ring 3: Deep inner ring
        drawCircle(
            color = if (isListening) ElectricTeal.copy(alpha = 0.15f) else TextSecondary.copy(alpha = 0.05f),
            radius = (baseRadius + ampBonus) * 0.82f,
            style = Stroke(width = 1.5f.dp.toPx())
        )
    }
}
