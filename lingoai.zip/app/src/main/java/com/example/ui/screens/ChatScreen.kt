package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ChatMessage
import com.example.ui.theme.*
import com.example.ui.viewmodel.EnglishLearningViewModel
import kotlinx.coroutines.launch

@Composable
fun ChatScreen(
    viewModel: EnglishLearningViewModel,
    onNavigateToVoiceChat: () -> Unit
) {
    val messages by viewModel.chatHistory.collectAsState()
    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current

    // Auto-scroll to lowest message when size grows
    LaunchedEffect(messages.size, viewModel.isAiGenerating) {
        if (messages.isNotEmpty()) {
            coroutineScope.launch {
                listState.animateScrollToItem(messages.size - 1)
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MidnightBg)
            .statusBarsPadding()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Interactive header with stats and clear database option
            ChatScreenHeader(
                tutorPersona = viewModel.tutorPersona,
                difficulty = viewModel.difficultyLevel,
                onClearHistory = { viewModel.clearChatHistory() }
            )

            // Conversation Chat List
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item { Spacer(modifier = Modifier.height(8.dp)) }

                if (messages.isEmpty()) {
                    item {
                        EmptyChatGreetingWidget(
                            tutor = viewModel.tutorPersona,
                            onSuggestionClicked = { viewModel.chatMessageInput = it }
                        )
                    }
                } else {
                    items(messages) { message ->
                        ChatMessageRow(
                            message = message,
                            viewModel = viewModel
                        )
                    }
                }

                if (viewModel.isAiGenerating) {
                    item {
                        AiTypingIndicatorIcon()
                    }
                }

                item { Spacer(modifier = Modifier.height(90.dp)) }
            }
        }

        // Floating Bottom Control Panel
        BottomTypeBarPanel(
            input = viewModel.chatMessageInput,
            onValueChange = { viewModel.chatMessageInput = it },
            onSubmitText = {
                viewModel.runTextInputSubmit()
                focusManager.clearFocus()
            },
            onNavigateToVoiceChat = onNavigateToVoiceChat,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
        )
    }
}

@Composable
fun ChatScreenHeader(
    tutorPersona: String,
    difficulty: String,
    onClearHistory: () -> Unit
) {
    Surface(
        color = MidnightSurface,
        tonalElevation = 6.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .background(ElectricTeal.copy(alpha = 0.15f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.SmartToy,
                        contentDescription = null,
                        tint = ElectricTeal,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = tutorPersona,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "$difficulty English Companion",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }
            }

            IconButton(
                onClick = onClearHistory,
                modifier = Modifier.testTag("clear_chat_history_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.DeleteSweep,
                    contentDescription = "Clear History",
                    tint = TextSecondary.copy(alpha = 0.7f)
                )
            }
        }
    }
}

@Composable
fun EmptyChatGreetingWidget(
    tutor: String,
    onSuggestionClicked: (String) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MidnightSurface),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp, horizontal = 4.dp)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.RecordVoiceOver,
                contentDescription = null,
                tint = ElectricTeal,
                modifier = Modifier.size(44.dp)
            )

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "Welcome, standard talker!",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                textAlign = TextAlign.Center
            )

            Text(
                text = "Hello! I am $tutor, your active English speaking partner. Tap the microphone under the input bar to talk using your voice, or write a question about travel, grammar, and pronunciation rules. Here are some prompts to start!",
                fontSize = 13.sp,
                color = TextSecondary,
                textAlign = TextAlign.Center,
                lineHeight = 18.sp,
                modifier = Modifier.padding(top = 8.dp)
            )

            Spacer(modifier = Modifier.height(18.dp))

            val prompts = listOf(
                "Can you review my weekend activities?",
                "Tell me standard business greeting tips",
                "How do I explain my hobby naturally?"
            )

            prompts.forEach { s ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MidnightSurfaceElevated),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clickable { onSuggestionClicked(s) }
                ) {
                    Text(
                        text = s,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = ElectricTeal,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ChatMessageRow(
    message: ChatMessage,
    viewModel: EnglishLearningViewModel
) {
    val isUser = message.sender == "user"
    var isExpandedCorrection by remember { mutableStateOf(false) }

    val pronunciationReport = remember(message.pronunciationScoreJson) {
        if (!message.pronunciationScoreJson.isNullOrEmpty()) {
            try {
                com.example.data.network.GeminiRetrofitClient.moshiInstance
                    .adapter(com.example.data.network.PronunciationReport::class.java)
                    .fromJson(message.pronunciationScoreJson)
            } catch (e: Exception) {
                null
            }
        } else {
            null
        }
    }

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(0.85f),
            horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
        ) {
            if (!isUser) {
                Icon(
                    imageVector = Icons.Default.Face,
                    contentDescription = null,
                    tint = NeonBlue,
                    modifier = Modifier
                        .padding(top = 4.dp, end = 8.dp)
                        .size(16.dp)
                )
            }

            // Word vault long-press saving trigger
            Box(
                modifier = Modifier
                    .clip(
                        RoundedCornerShape(
                            topStart = 16.dp,
                            topEnd = 16.dp,
                            bottomStart = if (isUser) 16.dp else 2.dp,
                            bottomEnd = if (isUser) 2.dp else 16.dp
                        )
                    )
                    .background(if (isUser) ElectricTeal else MidnightSurfaceElevated)
                    .combinedClickable(
                        onLongClick = {
                            // Extract first cleanly segmented word to help save manually
                            val clean = message.text.replace(Regex("[^a-zA-Z\\s]"), "")
                            val firstWord = clean.split(" ").firstOrNull { it.length > 2 } ?: "fluent"
                            viewModel.saveNewWord(
                                word = firstWord,
                                meaning = "Extracted from convo: " + firstWord.lowercase() + " context",
                                example = message.text,
                                category = "General"
                            )
                        },
                        onClick = {
                            if (message.isVoice) {
                                viewModel.speakSpecificText(message.text)
                            }
                        }
                    )
                    .padding(12.dp)
            ) {
                Column {
                    Text(
                        text = message.text,
                        fontSize = 14.sp,
                        color = if (isUser) Color.White else TextPrimary,
                        lineHeight = 19.sp
                    )

                    if (message.isVoice) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(top = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.VolumeUp,
                                contentDescription = "Listen",
                                tint = ElectricTeal,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Tap to listen",
                                fontSize = 10.sp,
                                color = TextSecondary,
                                fontStyle = FontStyle.Italic
                            )
                        }
                    }
                }
            }
        }

        // Correction details layout banner
        if (message.hasMistake && message.correctedText != null) {
            Spacer(modifier = Modifier.height(4.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth(0.85f)
                    .padding(start = if (isUser) 0.dp else 24.dp)
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SoftCoral.copy(alpha = 0.12f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .combinedClickable { isExpandedCorrection = !isExpandedCorrection }
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.ReportProblem,
                                    contentDescription = null,
                                    tint = SoftCoral,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Grammar Correction Detected",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SoftCoral
                                )
                            }
                            Icon(
                                imageVector = if (isExpandedCorrection) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                contentDescription = null,
                                tint = SoftCoral,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "Corrected: ",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextSecondary
                        )
                        Text(
                            text = message.correctedText ?: "",
                            fontSize = 13.sp,
                            color = ElectricTeal,
                            fontWeight = FontWeight.Medium
                        )

                        // Expandable checklist explanation
                        AnimatedVisibility(visible = isExpandedCorrection) {
                            Column(modifier = Modifier.padding(top = 8.dp)) {
                                Divider(color = SoftCoral.copy(alpha = 0.3f))
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = message.explanation ?: "Double check your verb forms and word order tags.",
                                    fontSize = 12.sp,
                                    color = TextPrimary,
                                    lineHeight = 16.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Pronunciation Scoring Feedback Card
        if (pronunciationReport != null) {
            Spacer(modifier = Modifier.height(6.dp))
            PronunciationFeedbackCard(
                report = pronunciationReport,
                modifier = Modifier
                    .fillMaxWidth(0.85f)
                    .padding(start = if (isUser) 0.dp else 24.dp)
            )
        }
    }
}

@Composable
fun AiTypingIndicatorIcon() {
    val infiniteTransition = rememberInfiniteTransition(label = "TypingTransition")
    val dotAlpha1 by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = keyframes {
                durationMillis = 800
                0.2f at 0
                0.8f at 400
                1f at 800
            },
            repeatMode = RepeatMode.Reverse
        ),
        label = "DotAlpha1"
    )

    val dotAlpha2 by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = keyframes {
                durationMillis = 800
                0.2f at 200
                0.8f at 600
                1f at 800
            },
            repeatMode = RepeatMode.Reverse
        ),
        label = "DotAlpha2"
    )

    val dotAlpha3 by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = keyframes {
                durationMillis = 800
                0.2f at 400
                0.8f at 700
                1f at 800
            },
            repeatMode = RepeatMode.Reverse
        ),
        label = "DotAlpha3"
    )

    Row(
        modifier = Modifier
            .padding(vertical = 8.dp)
            .background(MidnightSurface, RoundedCornerShape(12.dp))
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = Icons.Default.SmartToy,
            contentDescription = null,
            tint = ElectricTeal,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Row {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(TextPrimary.copy(alpha = dotAlpha1))
            )
            Spacer(modifier = Modifier.width(4.dp))
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(TextPrimary.copy(alpha = dotAlpha2))
            )
            Spacer(modifier = Modifier.width(4.dp))
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(TextPrimary.copy(alpha = dotAlpha3))
            )
        }
    }
}

@Composable
fun BottomTypeBarPanel(
    input: String,
    onValueChange: (String) -> Unit,
    onSubmitText: () -> Unit,
    onNavigateToVoiceChat: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = MidnightSurface,
        tonalElevation = 8.dp,
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Typing Input
            TextField(
                value = input,
                onValueChange = onValueChange,
                placeholder = { Text("Speak or type in English...", fontSize = 14.sp) },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = MidnightSurfaceElevated,
                    unfocusedContainerColor = MidnightSurfaceElevated,
                    disabledContainerColor = MidnightSurfaceElevated,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    cursorColor = ElectricTeal
                ),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .weight(1f)
                    .testTag("chat_text_input_field"),
                singleLine = true
            )

            Spacer(modifier = Modifier.width(8.dp))

            // Microphone action trigger
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            colors = listOf(ElectricTeal, NeonBlue)
                        )
                    )
                    .clickable { onNavigateToVoiceChat() }
                    .testTag("nav_to_voice_chat_btn"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Mic,
                    contentDescription = "Open Voice Screen",
                    tint = MidnightBg,
                    modifier = Modifier.size(20.dp)
                )
            }

            // Submit Text Button
            if (input.isNotBlank()) {
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                    onClick = onSubmitText,
                    modifier = Modifier
                        .size(46.dp)
                        .background(MidnightSurfaceElevated, CircleShape)
                        .testTag("send_msg_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "Send",
                        tint = ElectricTeal,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun PronunciationFeedbackCard(
    report: com.example.data.network.PronunciationReport,
    modifier: Modifier = Modifier
) {
    var isExpanded by remember { mutableStateOf(false) }

    Card(
        colors = CardDefaults.cardColors(containerColor = MidnightSurfaceElevated),
        shape = RoundedCornerShape(16.dp),
        modifier = modifier
            .fillMaxWidth()
            .clickable { isExpanded = !isExpanded }
            .testTag("pronunciation_feedback_card")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header Row: Overall score with tiny badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.RecordVoiceOver,
                        contentDescription = null,
                        tint = ElectricTeal,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Speaking Pronunciation",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }

                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = when {
                            report.overallScore >= 90 -> ElectricTeal.copy(alpha = 0.15f)
                            report.overallScore >= 75 -> AccentAmber.copy(alpha = 0.15f)
                            else -> SoftCoral.copy(alpha = 0.15f)
                        }
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "Score: ${report.overallScore}/100",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = when {
                            report.overallScore >= 90 -> ElectricTeal
                            report.overallScore >= 75 -> AccentAmber
                            else -> SoftCoral
                        },
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Grid of sub-scores
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Accuracy Score
                ScoreBarItem(
                    label = "Accuracy",
                    score = report.accuracyScore,
                    color = ElectricTeal,
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(8.dp))
                // Intonation Score
                ScoreBarItem(
                    label = "Intonation",
                    score = report.intonationScore,
                    color = NeonBlue,
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(8.dp))
                // Rhythm Score
                ScoreBarItem(
                    label = "Rhythm",
                    score = report.rhythmScore,
                    color = SoftCoral,
                    modifier = Modifier.weight(1f)
                )
            }

            // Expand hint or expanded content
            if (!isExpanded) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Tap to show details & syllables",
                        fontSize = 10.sp,
                        color = TextSecondary,
                        fontWeight = FontWeight.Medium
                    )
                    Icon(
                        imageVector = Icons.Default.ExpandMore,
                        contentDescription = "Expand",
                        tint = TextSecondary,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }

            AnimatedVisibility(visible = isExpanded) {
                Column(modifier = Modifier.padding(top = 12.dp)) {
                    HorizontalDivider(color = MidnightSurfaceElevated.copy(alpha = 0.5f), thickness = 1.dp)
                    Spacer(modifier = Modifier.height(10.dp))

                    // Phoneme Feedback section
                    Text(
                        text = "Phoneme Accuracy",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = ElectricTeal
                    )
                    Text(
                        text = report.phonemeFeedback,
                        fontSize = 12.sp,
                        color = TextPrimary,
                        lineHeight = 16.sp,
                        modifier = Modifier.padding(top = 2.dp, bottom = 10.dp)
                    )

                    // Word Stress Feedback section
                    Text(
                        text = "Word Stress & Rhythm",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = NeonBlue
                    )
                    Text(
                        text = report.wordStressFeedback,
                        fontSize = 12.sp,
                        color = TextPrimary,
                        lineHeight = 16.sp,
                        modifier = Modifier.padding(top = 2.dp, bottom = 10.dp)
                    )

                    // Areas of improvement tags
                    if (report.areasOfImprovement.isNotEmpty()) {
                        Text(
                            text = "Areas for Improvement",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = SoftCoral,
                            modifier = Modifier.padding(bottom = 4.dp)
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            report.areasOfImprovement.forEach { tag ->
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = SoftCoral.copy(alpha = 0.1f)),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = tag,
                                        fontSize = 10.sp,
                                        color = SoftCoral,
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                    )
                                }
                            }
                        }
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 12.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Collapse details",
                            fontSize = 10.sp,
                            color = TextSecondary,
                            fontWeight = FontWeight.Medium
                        )
                        Icon(
                            imageVector = Icons.Default.ExpandLess,
                            contentDescription = "Collapse",
                            tint = TextSecondary,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ScoreBarItem(
    label: String,
    score: Int,
    color: Color,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = label, fontSize = 10.sp, color = TextSecondary, fontWeight = FontWeight.Medium)
            Text(text = "$score%", fontSize = 10.sp, color = color, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { score / 100f },
            color = color,
            trackColor = color.copy(alpha = 0.15f),
            modifier = Modifier
                .fillMaxWidth()
                .height(4.dp)
                .clip(CircleShape)
        )
    }
}
