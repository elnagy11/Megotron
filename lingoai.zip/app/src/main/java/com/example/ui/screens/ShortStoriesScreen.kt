package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LessonStory
import com.example.ui.theme.*
import com.example.ui.viewmodel.EnglishLearningViewModel
import com.example.ui.viewmodel.KeyWordItem
import com.example.ui.viewmodel.QuizQuestion
import com.squareup.moshi.Moshi
import com.example.data.network.GeminiRetrofitClient

@Composable
fun ShortStoriesScreen(viewModel: EnglishLearningViewModel) {
    val storiesList by viewModel.lessonsStoriesList.collectAsState()
    val activeStory = viewModel.selectedStory

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MidnightBg)
            .statusBarsPadding()
    ) {
        if (activeStory != null && viewModel.isReadingModeActive) {
            // Immersive Reading Lounge overlay
            ActiveReadingLounge(
                story = activeStory,
                viewModel = viewModel,
                onExit = {
                    viewModel.stopStoryAudioNarration()
                    viewModel.isReadingModeActive = false
                    viewModel.selectedStory = null
                }
            )
        } else {
            // Standard Stories Feed
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 76.dp) // padding for rails
            ) {
                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Bilingual Stories",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = "Enhance listening and context reading with quizzes",
                    fontSize = 12.sp,
                    color = TextSecondary,
                    modifier = Modifier.padding(top = 2.dp, bottom = 20.dp)
                )

                if (storiesList.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = ElectricTeal)
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        items(storiesList) { story ->
                            StoryFeedListCard(
                                story = story,
                                onSelect = { viewModel.selectActiveStory(story) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StoryFeedListCard(
    story: LessonStory,
    onSelect: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MidnightSurface),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelect() }
            .testTag("story_feed_card_${story.title.take(10).lowercase().replace(" ", "_")}")
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .background(
                        if (story.isCompleted) SoftEmerald.copy(alpha = 0.15f) else ElectricTeal.copy(alpha = 0.12f),
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (story.isCompleted) Icons.Default.CloudQueue else Icons.Default.MenuBook,
                    contentDescription = null,
                    tint = if (story.isCompleted) SoftEmerald else ElectricTeal,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(MidnightSurfaceElevated)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = story.level,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (story.level == "Advanced") SoftCoral else if (story.level == "Intermediate") AccentAmber else SoftEmerald
                        )
                    }

                    if (story.isCompleted) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Completed",
                            tint = SoftEmerald,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = story.title,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )

                Text(
                    text = "Tap to enter active read & complete quiz challenges",
                    fontSize = 11.sp,
                    color = TextSecondary,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }

            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = TextSecondary
            )
        }
    }
}

@Composable
fun ActiveReadingLounge(
    story: LessonStory,
    viewModel: EnglishLearningViewModel,
    onExit: () -> Unit
) {
    val scrollState = rememberScrollState()
    val moshi = GeminiRetrofitClient.moshiInstance

    // Deserialize keywords and quizzes
    val wordsType = com.squareup.moshi.Types.newParameterizedType(List::class.java, KeyWordItem::class.java)
    val wordsAdapter = moshi.adapter<List<KeyWordItem>>(wordsType)
    val parsedKeywords = try {
        wordsAdapter.fromJson(story.keywordsJson) ?: emptyList()
    } catch (e: Exception) {
        emptyList()
    }

    val quizType = com.squareup.moshi.Types.newParameterizedType(List::class.java, QuizQuestion::class.java)
    val quizAdapter = moshi.adapter<List<QuizQuestion>>(quizType)
    val parsedQuizzes = try {
        quizAdapter.fromJson(story.quizJson) ?: emptyList()
    } catch (e: Exception) {
        emptyList()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MidnightBg)
    ) {
        // Upper back bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onExit,
                modifier = Modifier
                    .background(MidnightSurface, CircleShape)
                    .testTag("exit_reading_lounge_btn")
            ) {
                Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Exit Lounge", tint = TextPrimary)
            }

            Text(
                text = story.title,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )

            // Audio Play trigger
            IconButton(
                onClick = {
                    if (viewModel.isStoryTtsSpeaking) {
                        viewModel.stopStoryAudioNarration()
                    } else {
                        viewModel.speakStoryAudioNarration(story.content)
                    }
                },
                modifier = Modifier
                    .background(if (viewModel.isStoryTtsSpeaking) SoftCoral else MidnightSurfaceElevated, CircleShape)
                    .testTag("story_narration_audio_btn")
            ) {
                Icon(
                    imageVector = if (viewModel.isStoryTtsSpeaking) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = "Narration",
                    tint = if (viewModel.isStoryTtsSpeaking) MidnightBg else ElectricTeal
                )
            }
        }

        // Lounger scroll structure
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(scrollState)
                .padding(16.dp)
        ) {
            // Accent Level Indicator
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(ElectricTeal.copy(alpha = 0.15f))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = story.level,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = ElectricTeal
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Text(
                    text = "Bilingual Practice Lounge",
                    fontSize = 12.sp,
                    color = TextSecondary
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Main English text blocks
            Text(
                text = story.content,
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium,
                color = TextPrimary,
                lineHeight = 25.sp,
                modifier = Modifier.testTag("story_content_body_text")
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Inline Translation revealed button
            Card(
                colors = CardDefaults.cardColors(containerColor = MidnightSurface),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        viewModel.translationRevealedIndex = if (viewModel.translationRevealedIndex == 0) -1 else 0
                    }
                    .testTag("toggle_story_translation_block")
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Translate to ${viewModel.nativeLanguage}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = ElectricTeal
                        )
                        Icon(
                            imageVector = if (viewModel.translationRevealedIndex == 0) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                            contentDescription = null,
                            tint = ElectricTeal,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    AnimatedVisibility(visible = viewModel.translationRevealedIndex == 0) {
                        Column(modifier = Modifier.padding(top = 10.dp)) {
                            Divider(color = MidnightSurfaceElevated)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = story.translation,
                                fontSize = 14.sp,
                                color = TextSecondary,
                                lineHeight = 21.sp,
                                fontStyle = FontStyle.Italic
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Highlighted Vocabulary Section
            if (parsedKeywords.isNotEmpty()) {
                Text(
                    text = "Hard Vocabulary Spotlight",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    modifier = Modifier.padding(bottom = 10.dp)
                )

                parsedKeywords.forEach { item ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MidnightSurfaceElevated),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(text = item.word, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                                Text(text = item.meaning, fontSize = 11.sp, color = TextSecondary)
                            }

                            IconButton(
                                onClick = {
                                    viewModel.saveNewWord(
                                        word = item.word,
                                        meaning = item.meaning,
                                        example = "Spotted in story: \"${story.title}\"",
                                        category = "General"
                                    )
                                },
                                modifier = Modifier.testTag("vocab_story_bookmark_${item.word.lowercase()}")
                            ) {
                                Icon(imageVector = Icons.Default.BookmarkAdd, contentDescription = "Save", tint = ElectricTeal)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Quiz Section
            if (parsedQuizzes.isNotEmpty()) {
                Text(
                    text = "Reading Comprehension Quiz",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    modifier = Modifier.padding(bottom = 10.dp)
                )

                parsedQuizzes.forEachIndexed { qIdx, question ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MidnightSurface),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "Question ${qIdx + 1}: ${question.question}",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            question.options.forEachIndexed { oIdx, option ->
                                val scoreSelected = viewModel.selectedQuestionsAnswers[qIdx] == oIdx
                                val isCorrectOption = oIdx == question.answer
                                val showCorrectionColors = viewModel.showQuizResults

                                // Color logics
                                val rowColor = when {
                                    showCorrectionColors && isCorrectOption -> SoftEmerald.copy(alpha = 0.18f)
                                    showCorrectionColors && scoreSelected && !isCorrectOption -> SoftCoral.copy(alpha = 0.18f)
                                    scoreSelected -> ElectricTeal.copy(alpha = 0.12f)
                                    else -> MidnightSurfaceElevated
                                }

                                val textAccent = when {
                                    showCorrectionColors && isCorrectOption -> SoftEmerald
                                    showCorrectionColors && scoreSelected && !isCorrectOption -> SoftCoral
                                    scoreSelected -> ElectricTeal
                                    else -> TextSecondary
                                }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(rowColor)
                                        .clickable {
                                            if (!viewModel.showQuizResults) {
                                                val nextAnswers = viewModel.selectedQuestionsAnswers.toMutableMap()
                                                nextAnswers[qIdx] = oIdx
                                                viewModel.selectedQuestionsAnswers = nextAnswers
                                            }
                                        }
                                        .padding(12.dp)
                                        .testTag("quiz_${qIdx}_option_${oIdx}")
                                ) {
                                    Icon(
                                        imageVector = if (scoreSelected) Icons.Default.RadioButtonChecked else Icons.Default.RadioButtonUnchecked,
                                        contentDescription = null,
                                        tint = textAccent,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(
                                        text = option,
                                        fontSize = 12.sp,
                                        color = TextPrimary,
                                        fontWeight = if (scoreSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Submit/Verify Quiz Button
                val quizAnswersFinished = viewModel.selectedQuestionsAnswers.size == parsedQuizzes.size
                Button(
                    onClick = { viewModel.submitStoryQuizAnswers() },
                    enabled = quizAnswersFinished && !viewModel.showQuizResults,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ElectricTeal,
                        disabledContainerColor = MidnightSurfaceElevated
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("story_quiz_submit_btn")
                ) {
                    Text(
                        text = if (viewModel.showQuizResults) "Quiz Verified" else "Submit and Check",
                        color = if (quizAnswersFinished && !viewModel.showQuizResults) MidnightBg else TextSecondary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}
