package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.EnglishLearningViewModel

@Composable
fun SettingsScreen(
    viewModel: EnglishLearningViewModel,
    username: String,
    onNavigateBackToDashboard: () -> Unit
) {
    val scrollState = rememberScrollState()
    
    // Dropdown toggle states
    var isLanguageMenuOpen by remember { mutableStateOf(false) }
    var isPersonaMenuOpen by remember { mutableStateOf(false) }

    val languages = listOf("Spanish", "French", "German", "Arabic", "Chinese", "Hindi", "Japanese", "Turkish")
    val personas = listOf("Friendly Coach", "Formal Instructor", "Patient Mentor")

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MidnightBg)
            .statusBarsPadding()
            .padding(horizontal = 16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(bottom = 76.dp) // bottom navigation rail height padding
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Tutor Configurations",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Text(
                text = "Personalize artificial intelligence speech and levels",
                fontSize = 12.sp,
                color = TextSecondary,
                modifier = Modifier.padding(top = 2.dp, bottom = 20.dp)
            )

            // Dynamic User Profile Header Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MidnightSurface),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(ElectricTeal, NeonBlue)
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = username.take(1).uppercase(),
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = MidnightBg
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column {
                        Text(
                            text = username,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "Primary Native: ${viewModel.nativeLanguage} • Active",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // AI DIFFICULTY CURVES Setting Block
            Text(
                text = "AI Grammar Level",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = MidnightSurface),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Curate speech pace and expression difficulty matching your target curves:",
                        fontSize = 12.sp,
                        color = TextSecondary,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val levels = listOf("Beginner", "Intermediate", "Advanced")
                        levels.forEach { lvl ->
                            val isSelected = viewModel.difficultyLevel == lvl
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (isSelected) ElectricTeal else MidnightSurfaceElevated)
                                    .clickable { viewModel.difficultyLevel = lvl }
                                    .padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = lvl,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) MidnightBg else TextPrimary,
                                    modifier = Modifier.testTag("difficulty_level_chip_$lvl")
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Dropdown selection fields
            Text(
                text = "Translation & Personality settings",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = MidnightSurface),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    // 1. Language selector field
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { isLanguageMenuOpen = true }
                            .padding(vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Translate, contentDescription = null, tint = ElectricTeal)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("Native translation layer", fontSize = 14.sp, color = TextPrimary)
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(viewModel.nativeLanguage, fontSize = 14.sp, color = ElectricTeal, fontWeight = FontWeight.SemiBold)
                            Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null, tint = TextSecondary)
                        }
                    }

                    // Dropdown dropdown standard Material 3 implementation
                    DropdownMenu(
                        expanded = isLanguageMenuOpen,
                        onDismissRequest = { isLanguageMenuOpen = false },
                        modifier = Modifier.background(MidnightSurfaceElevated)
                    ) {
                        languages.forEach { lang ->
                            DropdownMenuItem(
                                text = { Text(lang, color = TextPrimary) },
                                onClick = {
                                    viewModel.nativeLanguage = lang
                                    isLanguageMenuOpen = false
                                },
                                modifier = Modifier.testTag("lang_menu_item_$lang")
                            )
                        }
                    }

                    Divider(color = MidnightSurfaceElevated)

                    // 2. Persona selection field
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { isPersonaMenuOpen = true }
                            .padding(vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Psychology, contentDescription = null, tint = ElectricTeal)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("Tutor Character Persona", fontSize = 14.sp, color = TextPrimary)
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(viewModel.tutorPersona, fontSize = 14.sp, color = ElectricTeal, fontWeight = FontWeight.SemiBold)
                            Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null, tint = TextSecondary)
                        }
                    }

                    DropdownMenu(
                        expanded = isPersonaMenuOpen,
                        onDismissRequest = { isPersonaMenuOpen = false },
                        modifier = Modifier.background(MidnightSurfaceElevated)
                    ) {
                        personas.forEach { per ->
                            DropdownMenuItem(
                                text = { Text(per, color = TextPrimary) },
                                onClick = {
                                    viewModel.tutorPersona = per
                                    isPersonaMenuOpen = false
                                },
                                modifier = Modifier.testTag("persona_menu_item_${per.lowercase().replace(" ", "_")}")
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // TTS SPEECH CONFIGURATION Setting Block
            Text(
                text = "Text-to-Speech Vocal Tuning",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = MidnightSurface),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    // Voice Speed rate title
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Speaking Speed rate:", fontSize = 13.sp, color = TextPrimary)
                        Text(
                            text = String.format("%.1fx Speed", viewModel.voiceSpeed),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = ElectricTeal
                        )
                    }

                    // Sliding rating bar
                    Slider(
                        value = viewModel.voiceSpeed,
                        onValueChange = { speed ->
                            viewModel.updateVoiceConfig(
                                female = viewModel.useFemaleVoice,
                                speed = speed
                            )
                        },
                        valueRange = 0.6f..1.5f,
                        colors = SliderDefaults.colors(
                            thumbColor = ElectricTeal,
                            activeTrackColor = ElectricTeal,
                            inactiveTrackColor = MidnightSurfaceElevated
                        ),
                        modifier = Modifier.testTag("voice_speed_slider")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Tutor pitch / gender select row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Vocal Accent Pitch:", fontSize = 13.sp, color = TextPrimary)
                        
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (viewModel.useFemaleVoice) ElectricTeal else MidnightSurfaceElevated)
                                    .clickable {
                                        viewModel.updateVoiceConfig(female = true, speed = viewModel.voiceSpeed)
                                    }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                                    .testTag("female_pitch_btn"),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "Female",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (viewModel.useFemaleVoice) MidnightBg else TextSecondary
                                )
                            }

                            Spacer(modifier = Modifier.width(6.dp))

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (!viewModel.useFemaleVoice) ElectricTeal else MidnightSurfaceElevated)
                                    .clickable {
                                        viewModel.updateVoiceConfig(female = false, speed = viewModel.voiceSpeed)
                                    }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                                    .testTag("male_pitch_btn"),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "Male",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (!viewModel.useFemaleVoice) MidnightBg else TextSecondary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Divider(color = MidnightSurfaceElevated)
                    Spacer(modifier = Modifier.height(10.dp))

                    // Dynamic text reading switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Auto Vocally Narration Speaking", fontSize = 14.sp, color = TextPrimary)
                            Text("Speaks AI replies immediately using audio tts", fontSize = 11.sp, color = TextSecondary)
                        }

                        Switch(
                            checked = viewModel.isTtsEnabled,
                            onCheckedChange = { viewModel.isTtsEnabled = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = ElectricTeal,
                                checkedTrackColor = ElectricTeal.copy(alpha = 0.4f),
                                uncheckedThumbColor = TextSecondary,
                                uncheckedTrackColor = MidnightSurfaceElevated
                            ),
                            modifier = Modifier.testTag("auto_narration_switch")
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Reset database data button for debug testing convenience
            OutlinedButton(
                onClick = { viewModel.clearChatHistory() },
                shape = RoundedCornerShape(12.dp),
                border = ButtonDefaults.outlinedButtonBorder.copy(),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = SoftCoral),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("reset_convo_db_btn")
            ) {
                Icon(imageVector = Icons.Default.Refresh, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Reset Learning Dialog Database", fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}
