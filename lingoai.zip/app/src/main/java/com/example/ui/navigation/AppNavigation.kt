package com.example.ui.navigation

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.EnglishLearningViewModel

enum class NavigationState {
    SPLASH,
    ONBOARDING,
    AUTH,
    MAIN_NAV_SHELL,
    FULLSCREEN_VOICE_CHAT
}

enum class TabDestinations(
    val title: String,
    val activeIcon: ImageVector,
    val inactiveIcon: ImageVector,
    val tag: String
) {
    DASHBOARD("Dashboard", Icons.Default.TrendingUp, Icons.Default.TrendingUp, "nav_tab_dashboard"),
    CHAT("AI Chat", Icons.Default.SmartToy, Icons.Default.SmartToy, "nav_tab_chat"),
    VAULT("Word Vault", Icons.Default.FolderSpecial, Icons.Default.FolderSpecial, "nav_tab_vault"),
    PHRASES("Phrases", Icons.Default.Translate, Icons.Default.Translate, "nav_tab_phrases"),
    STORIES("Stories", Icons.Default.MenuBook, Icons.Default.MenuBook, "nav_tab_stories"),
    SETTINGS("Settings", Icons.Default.Settings, Icons.Default.Settings, "nav_tab_settings")
}

@Composable
fun AppNavigationShell() {
    val viewModel: EnglishLearningViewModel = viewModel()
    
    // Core routing states
    var currentNavState by remember { mutableStateOf(NavigationState.SPLASH) }
    var activeTab by remember { mutableStateOf(TabDestinations.DASHBOARD) }
    var loggedInUsername by remember { mutableStateOf("FluentBuddy") }

    // Navigation flows
    when (currentNavState) {
        NavigationState.SPLASH -> {
            SplashScreen(
                onSplashFinished = {
                    currentNavState = NavigationState.ONBOARDING
                }
            )
        }
        NavigationState.ONBOARDING -> {
            OnboardingScreen(
                onOnboardingCompleted = {
                    currentNavState = NavigationState.AUTH
                }
            )
        }
        NavigationState.AUTH -> {
            AuthScreen(
                onAuthSucceeded = { username ->
                    loggedInUsername = username
                    currentNavState = NavigationState.MAIN_NAV_SHELL
                }
            )
        }
        NavigationState.FULLSCREEN_VOICE_CHAT -> {
            VoiceChatScreen(
                viewModel = viewModel,
                onBackToTextChat = {
                    currentNavState = NavigationState.MAIN_NAV_SHELL
                    activeTab = TabDestinations.CHAT
                }
            )
        }
        NavigationState.MAIN_NAV_SHELL -> {
            Scaffold(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MidnightBg),
                bottomBar = {
                    NavigationBar(
                        containerColor = MidnightSurface,
                        tonalElevation = 8.dp,
                        modifier = Modifier
                            .windowInsetsPadding(WindowInsets.navigationBars)
                            .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
                    ) {
                        TabDestinations.values().forEach { tab ->
                            val isSelected = activeTab == tab
                            NavigationBarItem(
                                selected = isSelected,
                                onClick = { activeTab = tab },
                                icon = {
                                    Icon(
                                        imageVector = tab.activeIcon,
                                        contentDescription = tab.title,
                                        tint = if (isSelected) MidnightBg else TextSecondary
                                    )
                                },
                                label = {
                                    Text(
                                        text = tab.title,
                                        fontSize = 11.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) ElectricTeal else TextSecondary
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    indicatorColor = ElectricTeal,
                                    selectedIconColor = MidnightBg,
                                    unselectedIconColor = TextSecondary
                                ),
                                modifier = Modifier.testTag(tab.tag)
                            )
                        }
                    }
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .background(MidnightBg)
                ) {
                    when (activeTab) {
                        TabDestinations.DASHBOARD -> {
                            DashboardScreen(
                                viewModel = viewModel,
                                username = loggedInUsername,
                                onStartPracticeClicked = { activeTab = TabDestinations.CHAT }
                            )
                        }
                        TabDestinations.CHAT -> {
                            ChatScreen(
                                viewModel = viewModel,
                                onNavigateToVoiceChat = {
                                    currentNavState = NavigationState.FULLSCREEN_VOICE_CHAT
                                }
                            )
                        }
                        TabDestinations.VAULT -> {
                            WordVaultScreen(viewModel = viewModel)
                        }
                        TabDestinations.PHRASES -> {
                            CommonPhrasesScreen(viewModel = viewModel)
                        }
                        TabDestinations.STORIES -> {
                            ShortStoriesScreen(viewModel = viewModel)
                        }
                        TabDestinations.SETTINGS -> {
                            SettingsScreen(
                                viewModel = viewModel,
                                username = loggedInUsername,
                                onNavigateBackToDashboard = { activeTab = TabDestinations.DASHBOARD }
                            )
                        }
                    }
                }
            }
        }
    }
}
