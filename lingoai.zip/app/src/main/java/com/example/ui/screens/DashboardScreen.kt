package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserProgress
import com.example.ui.theme.*
import com.example.ui.viewmodel.EnglishLearningViewModel
import com.squareup.moshi.Moshi
import com.example.data.network.GeminiRetrofitClient

@Composable
fun DashboardScreen(
    viewModel: EnglishLearningViewModel,
    username: String,
    onStartPracticeClicked: () -> Unit
) {
    val statsState by viewModel.userLearningStats.collectAsState()
    val stats = statsState ?: UserProgress()
    val scrollState = rememberScrollState()

    // Parse badges list
    val moshi = GeminiRetrofitClient.moshiInstance
    val adapter = moshi.adapter(List::class.java)
    val unlockedBadges = try {
        (adapter.fromJson(stats.badgeIdsJson) ?: emptyList<Any>()).map { it.toString() }
    } catch (e: Exception) {
        listOf("First Steps")
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MidnightBg)
            .statusBarsPadding()
            .padding(horizontal = 16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(bottom = 76.dp) // Bottom padding for navigation rails
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            // User Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Hello, $username!",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "Target Level: ${viewModel.difficultyLevel} • Speaking in English",
                        fontSize = 14.sp,
                        color = TextSecondary,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }

                // Streak Fire Display
                Card(
                    colors = CardDefaults.cardColors(containerColor = MidnightSurfaceElevated),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.testTag("streak_display_card")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocalFireDepartment,
                            contentDescription = "Streak Fire",
                            tint = SoftCoral,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${stats.streakCount} Days",
                            color = TextPrimary,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // XP and Level Progress block
            LevelProgressCard(stats.totalXp)

            Spacer(modifier = Modifier.height(20.dp))

            // Main Stats Grid Panel
            StatsGridPanel(stats)

            Spacer(modifier = Modifier.height(20.dp))

            // Daily Challenge Bar
            DailyChallengeWidget(stats)

            Spacer(modifier = Modifier.height(20.dp))

            // Weekly Grammar Success Progress Chart
            Card(
                colors = CardDefaults.cardColors(containerColor = MidnightSurface),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Grammar Competence Chart",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "Verification accuracy over sentences submitted",
                        fontSize = 12.sp,
                        color = TextSecondary,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    // Draw our dynamic chart via custom canvas
                    val checkedCount = stats.sentencesCheckedCount
                    val correctCount = stats.sentencesWithoutMistakes
                    val ratioOfNoError = if (checkedCount > 0) correctCount.toFloat() / checkedCount else 0.8f

                    GrammarCompetenceChartCanvas(ratioOfNoError)
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Badges Section Title
            Text(
                text = "My Achievements Badges",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            BadgesPresenterGrid(unlockedBadges)

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
fun LevelProgressCard(xp: Int) {
    val level = (xp / 100) + 1
    val currentLevelXp = xp % 100
    val progressFraction = currentLevelXp.toFloat() / 100f

    Card(
        colors = CardDefaults.cardColors(containerColor = MidnightSurface),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(ElectricTeal.copy(alpha = 0.15f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.TrendingUp,
                            contentDescription = null,
                            tint = ElectricTeal,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Speaker Level $level",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "$xp total XP earned",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                    }
                }

                Text(
                    text = "$currentLevelXp / 100 XP to Level ${level + 1}",
                    fontSize = 12.sp,
                    color = ElectricTeal,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Progress bar
            LinearProgressIndicator(
                progress = { progressFraction },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = ElectricTeal,
                trackColor = MidnightSurfaceElevated
            )
        }
    }
}

@Composable
fun StatsGridPanel(stats: UserProgress) {
    Row(modifier = Modifier.fillMaxWidth()) {
        Card(
            colors = CardDefaults.cardColors(containerColor = MidnightSurface),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .weight(1f)
                .padding(end = 8.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Icon(
                    imageVector = Icons.Default.Book,
                    contentDescription = null,
                    tint = ElectricTeal,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "${stats.totalWordsLearned}",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = "Saved Words",
                    fontSize = 12.sp,
                    color = TextSecondary
                )
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = MidnightSurface),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .weight(1f)
                .padding(start = 8.dp)
        ) {
            val minutesPlayed = stats.speakingSeconds / 60
            val secondsLeft = stats.speakingSeconds % 60
            val formattedSeconds = if (secondsLeft < 10) "0$secondsLeft" else "$secondsLeft"
            Column(modifier = Modifier.padding(16.dp)) {
                Icon(
                    imageVector = Icons.Default.HourglassEmpty,
                    contentDescription = null,
                    tint = NeonBlue,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "$minutesPlayed:$formattedSeconds",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = "Speaking Practice",
                    fontSize = 12.sp,
                    color = TextSecondary
                )
            }
        }
    }
}

@Composable
fun DailyChallengeWidget(stats: UserProgress) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MidnightSurface),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("daily_challenge_card")
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .background(AccentAmber.copy(alpha = 0.15f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Star,
                    contentDescription = null,
                    tint = AccentAmber,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Today's Challenge",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = "Speak for at least 30 seconds to lock 100 XP!",
                    fontSize = 12.sp,
                    color = TextSecondary,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }

            // Challenge success indicator
            val completed = stats.speakingSeconds >= 30
            Icon(
                imageVector = if (completed) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                contentDescription = null,
                tint = if (completed) SoftEmerald else TextSecondary,
                modifier = Modifier.size(26.dp)
            )
        }
    }
}

@Composable
fun GrammarCompetenceChartCanvas(percentage: Float) {
    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(130.dp)
    ) {
        val width = size.width
        val height = size.height
        val barCount = 7
        val margin = 20.dp.toPx()
        val spacing = 28.dp.toPx()
        val barWidth = (width - margin * 2 - spacing * (barCount - 1)) / barCount

        // Standard percentage offsets to simulate historical data
        val simulatedPreHistory = listOf(0.6f, 0.65f, 0.72f, 0.7f, 0.78f, 0.85f)
        val heightsList = simulatedPreHistory.map { it * height * 0.9f } + listOf(percentage * height * 0.9f)
        val dayLabels = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")

        // Draw background horizontal reference lines
        val strokeStyle = Stroke(width = 1.dp.toPx())
        val linesCount = 3
        for (i in 0 until linesCount) {
            val yPos = height * (i + 1) / (linesCount + 1)
            drawLine(
                color = MidnightSurfaceElevated,
                start = androidx.compose.ui.geometry.Offset(margin, yPos),
                end = androidx.compose.ui.geometry.Offset(width - margin, yPos),
                strokeWidth = 1.dp.toPx()
            )
        }

        // Draw Bars
        for (idx in 0 until barCount) {
            val h = heightsList[idx]
            val x = margin + idx * (barWidth + spacing)
            val y = height - h

            // Gradients for active/previous days
            val barBrush = Brush.verticalGradient(
                colors = if (idx == barCount - 1) {
                    listOf(ElectricTeal, NeonBlue)
                } else {
                    listOf(NeonBlue.copy(alpha = 0.5f), MidnightSurfaceElevated)
                }
            )

            drawRoundRect(
                brush = barBrush,
                topLeft = androidx.compose.ui.geometry.Offset(x, y),
                size = androidx.compose.ui.geometry.Size(barWidth, h),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(6.dp.toPx())
            )
        }
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        val dayLabels = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
        dayLabels.forEach { label ->
            Text(
                text = label,
                fontSize = 11.sp,
                color = TextSecondary,
                textAlign = TextAlign.Center,
                modifier = Modifier.width(36.dp)
            )
        }
    }
}

@Composable
fun BadgesPresenterGrid(unlocked: List<String>) {
    val allBadges = listOf(
        BadgeDef("First Steps", "Started the LingoAI fluency adventure", Icons.Default.DirectionsWalk, ElectricTeal),
        BadgeDef("Junior Speaker", "Earned more than 100 experience points", Icons.Default.EmojiEvents, NeonBlue),
        BadgeDef("Fluent Talker", "Earned more than 500 experience points", Icons.Default.WorkspacePremium, AccentAmber),
        BadgeDef("Word Gatherer", "Preserved 5 or more terms in Word Vault", Icons.Default.Book, SoftEmerald),
        BadgeDef("Lexicon master", "Preserved 15 or more terms in Word Vault", Icons.Default.School, SoftCoral),
        BadgeDef("Streak Hero", "Kept practicing for 3 continuous days", Icons.Default.LocalFireDepartment, SoftCoral)
    )

    // Simplified grid
    Column(modifier = Modifier.fillMaxWidth()) {
        allBadges.chunked(2).forEach { rowItems ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                rowItems.forEach { badge ->
                    val isLocked = !unlocked.contains(badge.id)
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isLocked) MidnightSurface.copy(alpha = 0.5f) else MidnightSurface
                        ),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("badge_card_${badge.id.lowercase().replace(" ", "_")}")
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(12.dp)
                                .fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .background(
                                        if (isLocked) MidnightSurfaceElevated else badge.color.copy(alpha = 0.15f),
                                        CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = badge.icon,
                                    contentDescription = badge.id,
                                    tint = if (isLocked) TextSecondary.copy(alpha = 0.4f) else badge.color,
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            Column {
                                Text(
                                    text = badge.id,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isLocked) TextSecondary.copy(alpha = 0.5f) else TextPrimary
                                )
                                Text(
                                    text = badge.desc,
                                    fontSize = 10.sp,
                                    color = TextSecondary,
                                    lineHeight = 13.sp,
                                    modifier = Modifier.padding(top = 2.dp)
                                )
                            }
                        }
                    }
                }

                // If odd number, pad row with empty box
                if (rowItems.size < 2) {
                    Box(modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

data class BadgeDef(
    val id: String,
    val desc: String,
    val icon: ImageVector,
    val color: Color
)
