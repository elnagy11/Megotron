package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.EnglishLearningViewModel

@Composable
fun CommonPhrasesScreen(viewModel: EnglishLearningViewModel) {
    var selectedCategory by remember { mutableStateOf("Essential") }
    var selectedLevel by remember { mutableStateOf("All") }
    var showTranslations by remember { mutableStateOf(true) }

    val categoriesList = listOf("Essential", "Travel", "Business", "Social")
    val levelList = listOf("All", "Beginner", "Intermediate", "Advanced")

    // Master Static Local Phrases Dataset
    val phrasesRepo = listOf(
        PhraseItem("How's everything going with you?", "Essential", "Beginner", "¿Cómo te va todo?", "hows ev-ree-thing go-ing with you"),
        PhraseItem("Could you please repeat that slower?", "Essential", "Beginner", "¿Podrías repetir eso más lento?", "coold you pleez re-peet that slo-wer"),
        PhraseItem("What do you reckon about this policy?", "Essential", "Intermediate", "¿Qué opinas sobre esta norma?", "what do you reh-kun a-bout this pol-i-see"),
        PhraseItem("Let's touch base on this project next week.", "Essential", "Advanced", "Hablemos de este proyecto la próxima semana.", "lets tuch bays on this pro-ject next week"),
        PhraseItem("I would like to purchase a boarding ticket.", "Travel", "Beginner", "Me gustaría comprar un boleto de abordar.", "i wood like to purch-as a bor-ding tik-et"),
        PhraseItem("Where is the baggage claim carousel terminal?", "Travel", "Intermediate", "¿Dónde está la terminal de reclamo de equipaje?", "wair iz the bag-ij klaym ka-roo-sel"),
        PhraseItem("My flight departure got delayed indefinitely.", "Travel", "Advanced", "La salida de mi vuelo se retrasó indefinidamente.", "my flyt de-par-chur got de-layed in-def-i-nit-lee"),
        PhraseItem("Nice to meet you, looking forward to working with you.", "Business", "Beginner", "Mucho gusto, ansioso por trabajar contigo.", "nys to meet you loo-king for-ward to wur-king"),
        PhraseItem("We need to evaluate the quarterly budget surplus.", "Business", "Intermediate", "Necesitamos evaluar el superávit presupuestario trimestral.", "we need to e-val-yoo-ayt the kwor-ter-lee buj-et"),
        PhraseItem("Let's leverage our core competencies to maximize efficiency.", "Business", "Advanced", "Aprovechemos nuestras competencias clave para maximizar la eficiencia.", "lets lev-er-ij owr kor com-pe-ten-sees"),
        PhraseItem("Do you mind if I join your table?", "Social", "Beginner", "¿Te importa si me uno a tu mesa?", "do you mynd if i joyn yowr tay-bul"),
        PhraseItem("That sounds like an incredible opportunity!", "Social", "Intermediate", "¡Eso suena como una oportunidad increíble!", "that sownds like an in-cred-i-bul op-or-too-ni-tee"),
        PhraseItem("I was completely blown away by her final remarks.", "Social", "Advanced", "Me quedé completamente impresionado por sus palabras finales.", "i wuz com-pleet-ly blown a-way by her fy-nal re-marks")
    )

    // filter phrases
    val matchingPhrases = phrasesRepo.filter { item ->
        val catMatches = item.category == selectedCategory
        val lvlMatches = selectedLevel == "All" || item.level == selectedLevel
        catMatches && lvlMatches
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MidnightBg)
            .statusBarsPadding()
            .padding(horizontal = 16.dp)
            .padding(bottom = 76.dp) // padding for rails
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        // Phrases Title Section
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Common English Phrases",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = "Most spoken situational expressions built-in",
                    fontSize = 12.sp,
                    color = TextSecondary,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }

            // Translation toggle icon
            IconButton(
                onClick = { showTranslations = !showTranslations },
                modifier = Modifier
                    .background(MidnightSurfaceElevated, CircleShape)
                    .testTag("toggle_phrases_translation_btn")
            ) {
                Icon(
                    imageVector = if (showTranslations) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                    contentDescription = "Toggle Translations",
                    tint = ElectricTeal
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Horizontal Categories Row
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(categoriesList) { cat ->
                val isSelected = selectedCategory == cat
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isSelected) ElectricTeal else MidnightSurface)
                        .clickable { selectedCategory = cat }
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                        .testTag("phrase_category_chip_$cat")
                ) {
                    Text(
                        text = "$cat English",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) MidnightBg else TextSecondary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Level sub-row filters
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            levelList.forEach { lvl ->
                val isSelected = selectedLevel == lvl
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) NeonBlue.copy(alpha = 0.25f) else Color.Transparent)
                        .clickable { selectedLevel = lvl }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = lvl,
                        fontSize = 11.sp,
                        color = if (isSelected) ElectricTeal else TextSecondary,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Grid List of Expressions
        if (matchingPhrases.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No matched phrases.",
                    color = TextSecondary,
                    fontSize = 14.sp
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(matchingPhrases) { phrase ->
                    PhraseDisplayCard(
                        phrase = phrase,
                        showTranslation = showTranslations,
                        onSpeak = { viewModel.speakSpecificText(phrase.text) },
                        onRegisterInVault = {
                            viewModel.saveNewWord(
                                word = phrase.text,
                                meaning = phrase.translation,
                                example = "Pronunciation rule: " + phrase.phonetics,
                                category = phrase.category
                            )
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun PhraseDisplayCard(
    phrase: PhraseItem,
    showTranslation: Boolean,
    onSpeak: () -> Unit,
    onRegisterInVault: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MidnightSurface),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("phrase_card_${phrase.text.take(15).lowercase().replace(" ", "_")}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(MidnightSurfaceElevated)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = phrase.level,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (phrase.level == "Advanced") SoftCoral else if (phrase.level == "Intermediate") AccentAmber else SoftEmerald
                            )
                        }
                        
                        Spacer(modifier = Modifier.width(8.dp))
                        
                        Text(
                            text = phrase.category,
                            fontSize = 10.sp,
                            color = ElectricTeal,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = phrase.text,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = "Phonetics: [ ${phrase.phonetics} ]",
                        fontSize = 11.sp,
                        fontStyle = FontStyle.Italic,
                        color = TextSecondary
                    )
                }

                // Control widgets
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    IconButton(
                        onClick = onSpeak,
                        modifier = Modifier
                            .background(MidnightSurfaceElevated, CircleShape)
                            .size(36.dp)
                            .testTag("phrase_speak_btn_${phrase.text.take(5).lowercase()}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = "Speak Phrase",
                            tint = ElectricTeal,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    IconButton(
                        onClick = onRegisterInVault,
                        modifier = Modifier
                            .background(MidnightSurfaceElevated, CircleShape)
                            .size(36.dp)
                            .testTag("phrase_save_to_vault_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.BookmarkBorder,
                            contentDescription = "Save phrase to vault",
                            tint = TextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            // Expandable/Toggled Translations Details
            AnimatedVisibility(visible = showTranslation) {
                Column(modifier = Modifier.padding(top = 10.dp)) {
                    Divider(color = MidnightSurfaceElevated, thickness = 1.dp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = phrase.translation,
                        fontSize = 13.sp,
                        color = TextSecondary,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}

data class PhraseItem(
    val text: String,
    val category: String,
    val level: String,
    val translation: String,
    val phonetics: String
)
// Class definitions match essential targets
