package com.example.data.network

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class GenerateContentRequest(
    val contents: List<Content>,
    val generationConfig: GenerationConfig? = null,
    val systemInstruction: Content? = null
)

@JsonClass(generateAdapter = true)
data class Content(
    val role: String? = null,
    val parts: List<Part>
)

@JsonClass(generateAdapter = true)
data class Part(
    val text: String
)

@JsonClass(generateAdapter = true)
data class GenerationConfig(
    val temperature: Float? = null,
    val responseMimeType: String? = null
)

@JsonClass(generateAdapter = true)
data class GenerateContentResponse(
    val candidates: List<Candidate>?
)

@JsonClass(generateAdapter = true)
data class Candidate(
    val content: Content?
)

/**
 * Our custom structured response parsed from the Gemini-generated JSON.
 */
@JsonClass(generateAdapter = true)
data class PronunciationReport(
    val accuracyScore: Int,
    val intonationScore: Int,
    val rhythmScore: Int,
    val overallScore: Int,
    val phonemeFeedback: String,
    val wordStressFeedback: String,
    val areasOfImprovement: List<String>
)

@JsonClass(generateAdapter = true)
data class EnglishCorrectionReport(
    val reply: String,                     // Natural response to user message
    val correctedText: String?,            // Fully corrected text, null if perfect
    val hasMistake: Boolean,               // true if grammar, spelling, or vocabulary mistakes detected
    val mistakesExplanation: String?,      // Simple explanations in language learner friendly format
    val learningTidbit: String?,           // A vocabulary booster, alternative idiom, or rule hint
    val pronunciationTip: String?,         // A brief phonetics/speaking tip
    val pronunciationFeedback: PronunciationReport? = null
)
