package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.dao.ChatDao
import com.example.data.dao.ProgressDao
import com.example.data.dao.StoryDao
import com.example.data.dao.WordDao
import com.example.data.model.ChatMessage
import com.example.data.model.LessonStory
import com.example.data.model.SavedWord
import com.example.data.model.UserProgress

@Database(
    entities = [
        SavedWord::class,
        ChatMessage::class,
        LessonStory::class,
        UserProgress::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun wordDao(): WordDao
    abstract fun chatDao(): ChatDao
    abstract fun storyDao(): StoryDao
    abstract fun progressDao(): ProgressDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "lingoai_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
