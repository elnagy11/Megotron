package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chat_messages")
data class ChatMessage(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val sender: String, // "user" or "ai"
    val text: String,
    val correctedText: String? = null,
    val explanation: String? = null,
    val hasMistake: Boolean = false,
    val timestamp: Long = System.currentTimeMillis(),
    val isVoice: Boolean = false,
    val speakingDurationSec: Int = 0,
    val pronunciationScoreJson: String? = null
)
