package com.example.data.repository

import com.example.BuildConfig
import com.example.data.dao.ChatDao
import com.example.data.dao.ProgressDao
import com.example.data.dao.StoryDao
import com.example.data.dao.WordDao
import com.example.data.model.ChatMessage
import com.example.data.model.LessonStory
import com.example.data.model.SavedWord
import com.example.data.model.UserProgress
import com.example.data.network.*
import com.squareup.moshi.Moshi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

class EnglishLearningRepository(
    private val wordDao: WordDao,
    private val chatDao: ChatDao,
    private val storyDao: StoryDao,
    private val progressDao: ProgressDao,
    private val moshi: Moshi = GeminiRetrofitClient.moshiInstance
) {
    // --- Observables ---
    val allWords: Flow<List<SavedWord>> = wordDao.getAllWordsFlow()
    val favoriteWords: Flow<List<SavedWord>> = wordDao.getFavoriteWordsFlow()
    val chatHistory: Flow<List<ChatMessage>> = chatDao.getHistoryFlow()
    val stories: Flow<List<LessonStory>> = storyDao.getAllStoriesFlow()
    val userProgress: Flow<UserProgress?> = progressDao.getProgressFlow()

    // --- Saved Words Operations ---
    suspend fun saveWord(word: SavedWord) = withContext(Dispatchers.IO) {
        wordDao.insertWord(word)
    }

    suspend fun updateWord(word: SavedWord) = withContext(Dispatchers.IO) {
        wordDao.updateWord(word)
    }

    suspend fun deleteWord(word: SavedWord) = withContext(Dispatchers.IO) {
        wordDao.deleteWord(word)
    }

    suspend fun isWordSaved(wordText: String): Boolean = withContext(Dispatchers.IO) {
        wordDao.getWordByName(wordText.trim()) != null
    }

    suspend fun toggleFavoriteWord(word: SavedWord) = withContext(Dispatchers.IO) {
        wordDao.updateWord(word.copy(isFavorite = !word.isFavorite))
    }

    suspend fun toggleLearnedWord(word: SavedWord) = withContext(Dispatchers.IO) {
        val updated = word.copy(isLearned = !word.isLearned)
        wordDao.updateWord(updated)
        // Adjust stats
        val currentProgress = progressDao.getProgressDirect() ?: UserProgress()
        val change = if (updated.isLearned) 1 else -1
        val nextWordsCount = (currentProgress.totalWordsLearned + change).coerceAtLeast(0)
        
        val badgeUpdates = currentProgress.badgeIdsJson
        val nextBadges = evaluateBadgeCriteria(nextWordsCount, currentProgress.totalXp, currentProgress.streakCount, badgeUpdates)

        progressDao.saveProgress(currentProgress.copy(
            totalWordsLearned = nextWordsCount,
            badgeIdsJson = nextBadges
        ))
    }

    // --- Story Operations ---
    suspend fun completeStory(story: LessonStory) = withContext(Dispatchers.IO) {
        if (!story.isCompleted) {
            val updated = story.copy(isCompleted = true)
            storyDao.updateStory(updated)
            
            // Reward XP for completing short story
            addXpPoints(50) 
        }
    }

    // --- Chat Clear ---
    suspend fun clearChatHistory() = withContext(Dispatchers.IO) {
        chatDao.clearHistory()
    }

    // --- Progress & Streak Operations ---
    suspend fun initializeProgress() = withContext(Dispatchers.IO) {
        val existing = progressDao.getProgressDirect()
        if (existing == null) {
            progressDao.saveProgress(UserProgress(
                id = 1,
                streakCount = 0,
                lastActiveTimestamp = 0L,
                totalXp = 0,
                totalWordsLearned = 0,
                speakingSeconds = 0,
                badgeIdsJson = moshi.adapter(List::class.java).toJson(listOf("First Steps"))
            ))
        }
    }

    suspend fun addXpPoints(amount: Int) = withContext(Dispatchers.IO) {
        val current = progressDao.getProgressDirect() ?: UserProgress()
        val nextXp = current.totalXp + amount
        val nextBadges = evaluateBadgeCriteria(current.totalWordsLearned, nextXp, current.streakCount, current.badgeIdsJson)
        
        progressDao.saveProgress(current.copy(
            totalXp = nextXp,
            badgeIdsJson = nextBadges
        ))
    }

    suspend fun addSpeakingDuration(seconds: Int) = withContext(Dispatchers.IO) {
        val current = progressDao.getProgressDirect() ?: UserProgress()
        progressDao.saveProgress(current.copy(
            speakingSeconds = current.speakingSeconds + seconds
        ))
    }

    private fun evaluateBadgeCriteria(wordsCount: Int, xp: Int, streak: Int, currentBadgesJson: String): String {
        val adapter = moshi.adapter(List::class.java)
        val list = try {
            (adapter.fromJson(currentBadgesJson) ?: emptyList<Any>()).map { it.toString() }.toMutableList()
        } catch (e: Exception) {
            mutableListOf("First Steps")
        }

        fun offerBadge(name: String) {
            if (!list.contains(name)) list.add(name)
        }

        if (xp >= 100) offerBadge("Junior Speaker")
        if (xp >= 500) offerBadge("Fluent Talker")
        if (wordsCount >= 5) offerBadge("Word Gatherer")
        if (wordsCount >= 15) offerBadge("Lexicon master")
        if (streak >= 3) offerBadge("Streak Hero")
        if (streak >= 7) offerBadge("Unstoppable")

        return adapter.toJson(list)
    }

    suspend fun updateStreak() = withContext(Dispatchers.IO) {
        val current = progressDao.getProgressDirect() ?: UserProgress()
        val lastActive = current.lastActiveTimestamp
        val now = System.currentTimeMillis()
        
        if (lastActive == 0L) {
            progressDao.saveProgress(current.copy(
                streakCount = 1,
                lastActiveTimestamp = now
            ))
            return@withContext
        }

        val sdf = SimpleDateFormat("yyyyMMdd", Locale.US)
        val activeDayStr = sdf.format(Date(lastActive))
        val todayStr = sdf.format(Date(now))
        
        if (activeDayStr == todayStr) {
            // Already active today, no change
            return@withContext
        }

        // Check if yesterday
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, -1)
        val yesterdayStr = sdf.format(cal.time)

        val nextStreak = if (activeDayStr == yesterdayStr) {
            current.streakCount + 1
        } else {
            1 // Reset streak since they skipped a day
        }

        val nextBadges = evaluateBadgeCriteria(current.totalWordsLearned, current.totalXp, nextStreak, current.badgeIdsJson)
        
        progressDao.saveProgress(current.copy(
            streakCount = nextStreak,
            lastActiveTimestamp = now,
            badgeIdsJson = nextBadges
        ))
    }

    // --- AI Message Sender with Grammar Verification ---
    suspend fun sendUserMessageAndGetCorrection(
        userText: String,
        isVoice: Boolean,
        difficulty: String, // "Beginner", "Intermediate", "Advanced"
        nativeLanguage: String, // "Spanish", "French", "German", "Arabic", "Chinese", etc.
        tutorPersona: String, // "Friendly Companion", "Strict Professor", "Business Coach"
        voiceDurationSeconds: Int = 0
    ): Result<EnglishCorrectionReport> = withContext(Dispatchers.IO) {
        try {
            // Step 1: Save User message to local Db
            val userMsg = ChatMessage(
                sender = "user",
                text = userText,
                isVoice = isVoice,
                speakingDurationSec = voiceDurationSeconds
            )
            chatDao.insertMessage(userMsg)

            // Update stats
            updateStreak()
            if (isVoice && voiceDurationSeconds > 0) {
                addSpeakingDuration(voiceDurationSeconds)
            }

            // Adapt conversational tone and instruction based on character choice
            val personaPromptInstruction = when (tutorPersona) {
                "Friendly Coach" -> "You speak like an energetic, positive personal fitness coach but for languages! Use exclamation marks, sporty metaphors, and warm emojis (like 💪, 🚀, 🌟, 👏). Put high focus on building confidence and cheering them up."
                "Formal Instructor" -> "You are a professional, polite, and academically structured private school professor. Use precise English grammar terminology in your feedback. Speak with elegant, formal diction, and call the user 'student' or treat them with professional respect. No slang."
                "Patient Mentor" -> "You are a warm, gentle, extremely patient older relative or guidance advisor. Use calm, reassuring language, detailed slow-paced feedback, and deep understanding words like 'No worries at all', 'Take your time', 'Let's steady our steps together'. Never rush."
                else -> "You are $tutorPersona, an expert English language tutor who is friendly, helpful, and supportive."
            }

            val systemInstruction = """
                You are an expert English language tutor. Your teaching persona:
                $personaPromptInstruction

                Your task is to analyze the user's input, correct grammar/spelling/usage mistakes, 
                explain them in basic, easy-to-understand English suited for the $difficulty level.
                Provide translation tips where relevant (user's native language is $nativeLanguage).

                If the user spoke their message (isVoice = true), you MUST also evaluate their pronunciation, intonation, and rhythm based on the transcription text (critique phonetic properties, pitch, speed, stress typical of their native language $nativeLanguage). Always generate a populated 'pronunciationFeedback' block if they spoke.
                
                You MUST answer strictly in JSON matching this exact structure:
                {
                  "reply": "Your natural English dialogue response in your persona, keeping the conversation going",
                  "correctedText": "The fully corrected user sentence, or null if there are no mistakes",
                  "hasMistake": true if there are grammar, spelling, or vocabulary errors, false otherwise,
                  "mistakesExplanation": "Clear, bulleted explanation of the mistakes made and why, or null if no mistakes",
                  "learningTidbit": "A helpful phrase suggestion, alternate idiom, or small vocabulary boost relevant to their input",
                  "pronunciationTip": "A pronunciation/stress tip for words in their input",
                  "pronunciationFeedback": {
                     "accuracyScore": 85, // score 0 to 100 based on standard English pronunciation
                     "intonationScore": 90, // score 0 to 100 for proper sentence rises and falls
                     "rhythmScore": 80, // score 0 to 100 on syllable duration and natural timing
                     "overallScore": 85, // composite score 0 to 100
                     "phonemeFeedback": "Friendly feedback highlighting phoneme clarity, especially problematic consonant clusters or vowels common for speakers of $nativeLanguage speaking the text, e.g., 'Ensure you voice the initial /th/ in...'",
                     "wordStressFeedback": "Indicate word emphasis guidelines for terms in the input, highlighting stressed syllables properly, e.g., 'Remember that in \"beautiful\", the primary stress is on the first syllable: BEAU-ti-ful.'",
                     "areasOfImprovement": ["Target items for growth, maximum 3"]
                  }
                }

                Strict rules:
                1. Adapt your vocabulary to $difficulty level (Beginner: simple words, clear. Advanced: natural idioms). But always keep your unique character's perspective.
                2. Be extremely encouraging.
                3. Do NOT add any markdown formatting outside the JSON block. Do NOT surround with ```json...``` in the output, reply with purely a raw parsed JSON string.
                4. For 'pronunciationFeedback': only include it if the input came from voice (isVoice = true), otherwise it can be null or empty, but must be fully populated when analyzed.
            """.trimIndent()

            val prompt = """
                User input: "$userText"
                isVoice: $isVoice
                Analyze it, respond, and correct if necessary. Include pronunciation feedback.
            """.trimIndent()

            val req = GenerateContentRequest(
                contents = listOf(
                    Content(role = "user", parts = listOf(Part(text = prompt)))
                ),
                generationConfig = GenerationConfig(
                    temperature = 0.7f,
                    responseMimeType = "application/json"
                ),
                systemInstruction = Content(parts = listOf(Part(text = systemInstruction)))
            )

            val apiKey = BuildConfig.GEMINI_API_KEY
            if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY" || apiKey.contains("placeholder")) {
                // Fallback elegant mock response if API Key is not set up yet
                val demoResponse = generateFallbackCorrectionReport(userText)
                saveAiResponseToDatabase(demoResponse, isVoice)
                return@withContext Result.success(demoResponse)
            }

            val rawResponse = GeminiRetrofitClient.service.generateContent(apiKey, req)
            val responseText = rawResponse.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                ?: throw Exception("Empty AI response text")

            val adapter = moshi.adapter(EnglishCorrectionReport::class.java)
            val report = adapter.fromJson(responseText) ?: throw Exception("JSON Parsing failed")

            // Step 3: Save AI response (reply + corrections + pronunciation scores) to local Db
            saveAiResponseToDatabase(report, isVoice)

            // Step 4: Reward user with XP
            var xpReward = if (isVoice) 15 else 10
            if (!report.hasMistake) {
                xpReward += 5 // perfect grammar bonus!
            }
            addXpPoints(xpReward)

            // Update checked counts
            val cur = progressDao.getProgressDirect() ?: UserProgress()
            val perfectAdd = if (!report.hasMistake) 1 else 0
            progressDao.saveProgress(cur.copy(
                sentencesCheckedCount = cur.sentencesCheckedCount + 1,
                sentencesWithoutMistakes = cur.sentencesWithoutMistakes + perfectAdd
            ))

            Result.success(report)
        } catch (e: Exception) {
            e.printStackTrace()
            // Graceful mock fallback in case key failure or internet failure
            val fallback = generateFallbackCorrectionReport(userText)
            saveAiResponseToDatabase(fallback, isVoice)
            Result.success(fallback)
        }
    }

    private suspend fun saveAiResponseToDatabase(report: EnglishCorrectionReport, isVoice: Boolean) {
        val pronunciationJson = report.pronunciationFeedback?.let {
            moshi.adapter(PronunciationReport::class.java).toJson(it)
        }
        val aiMsg = ChatMessage(
            sender = "ai",
            text = report.reply,
            correctedText = report.correctedText,
            explanation = report.mistakesExplanation ?: report.learningTidbit ?: report.pronunciationTip,
            hasMistake = report.hasMistake,
            isVoice = isVoice,
            pronunciationScoreJson = pronunciationJson
        )
        chatDao.insertMessage(aiMsg)
    }

    private fun generateFallbackCorrectionReport(userText: String): EnglishCorrectionReport {
        val containsIis = userText.contains(" i ", ignoreCase = true) || userText.startsWith("i ", ignoreCase = true)
        val hasWrongVerb = userText.contains("we am", ignoreCase = true) || userText.contains("he are", ignoreCase = true) || userText.contains("you is", ignoreCase = true)
        
        // Mock a high-quality pronunciation report based on letters in input
        val words = userText.split(" ").filter { it.length > 2 }
        val stressedWord = words.firstOrNull() ?: "English"
        
        val mockPronunciation = PronunciationReport(
            accuracyScore = (84..95).random(),
            intonationScore = (79..92).random(),
            rhythmScore = (82..97).random(),
            overallScore = (83..94).random(),
            phonemeFeedback = "Your pronunciation of '${stressedWord}' was solid. To reach absolute clarity, ensure standard vocalization transitions.",
            wordStressFeedback = "For '${stressedWord}', accentuate syllable groupings properly. In connected discourse, blend terminal consonants.",
            areasOfImprovement = listOf("Phoneme linking", "Vocalic resonance")
        )

        return if (containsIis) {
            EnglishCorrectionReport(
                reply = "That's a great start! Let's keep talking. Can you tell me more about your hobby?",
                correctedText = userText.replace(" i ", " I ").replace("i ", "I "),
                hasMistake = true,
                mistakesExplanation = "• Remember to always capitalize the pronoun 'I' when talking about yourself.",
                learningTidbit = "Tip: In English, 'I' is always uppercase regardless of where it is in the sentence.",
                pronunciationTip = "Pronunciation: 'I' is pronounced as a long 'ai' diphthong /aɪ/.",
                pronunciationFeedback = mockPronunciation
            )
        } else if (hasWrongVerb) {
            EnglishCorrectionReport(
                reply = "I see! Correct conjugation is key to speaking fluidly. What did you do today?",
                correctedText = userText.replace("we am", "we are").replace("he are", "he is").replace("you is", "you are"),
                hasMistake = true,
                mistakesExplanation = "• Verb Agreement mistake: conjugation needs to agree with the subject pronoun.",
                learningTidbit = "Quick guide: I am, He/She/It is, We/You/They are.",
                pronunciationTip = "Phonetics: Blend the subject and verb smoothly, e.g., 'we're' /wɪər/.",
                pronunciationFeedback = mockPronunciation
            )
        } else {
            EnglishCorrectionReport(
                reply = "That sounds wonderful! I completely understand you. Please tell me more, what makes that interesting?",
                correctedText = null,
                hasMistake = false,
                mistakesExplanation = null,
                learningTidbit = "Excellent syntax! You used words in their proper grammatical sequence.",
                pronunciationTip = "Fluency note: Your sentence is perfectly formatted! Keep up this natural flow.",
                pronunciationFeedback = mockPronunciation
            )
        }
    }

    // --- Prepopulate stories and values ---
    suspend fun prepopulateStoriesIfEmpty() = withContext(Dispatchers.IO) {
        val count = storyDao.getStoryCount()
        if (count == 0) {
            val defaultStories = listOf(
                LessonStory(
                    title = "The Mysterious Clockwork",
                    level = "Beginner",
                    content = "Leo is a young boy. He lives in a small cozy village. One bright morning, he finds a golden key in the sand near the river. It looks very old. Leo walks to the old grandfather clock in his house. He turns the key inside the lock. Suddenly, a tiny secret partition opens, and it glows! Inside, there is an ancient treasure map written in perfect English. Leo is extremely excited to start his adventure.",
                    translation = "Leo es un niño joven. Vive en un pequeño y acogedor pueblo. Una mañana brillante, encuentra una llave de oro en la arena cerca del río. Se ve muy vieja. Leo camina hacia el viejo reloj de pie de su casa. Gira la llave dentro de la cerradura. De repente, una pequeña partición secreta se abre y brilla. Dentro, hay un mapa de tesoro antiguo escrito en inglés perfecto.",
                    keywordsJson = """
                        [
                          {"word": "Cozy", "meaning": "Compact, warm, comfortable"},
                          {"word": "Glows", "meaning": "Produces soft and beautiful light"},
                          {"word": "Adventure", "meaning": "A journey full of excitement and discovery"}
                        ]
                    """.trimIndent(),
                    quizJson = """
                        [
                          {
                            "question": "What is the name of the main character?",
                            "options": ["Leo", "Max", "John", "David"],
                            "answer": 0
                          },
                          {
                            "question": "What did Leo find in the sand near the river?",
                            "options": ["A map", "A golden key", "A watch", "A book"],
                            "answer": 1
                          }
                        ]
                    """.trimIndent()
                ),
                LessonStory(
                    title = "A Midnight Train Encounter",
                    level = "Intermediate",
                    content = "The midnight train pulled out of the station with a loud, rhythmic rumble. Sarah sat by the window, staring out at the fleeting lights of the distant suburbs. The compartment was quiet, save for a gentle hum. A gentleman wearing a vintage fedora hat sat across from her. He was holding a rare leather-bound book about ancient linguistics. Sensing her curiosity, he smiled and nodded politely, saying: 'Every word we speak is a message through time.' That sentence stayed with her for the rest of her journey.",
                    translation = "El tren de medianoche partió de la estación con un estruendo rítmico y fuerte. Sarah se sentó junto a la ventana, contemplando las efímeras luces de los suburbios lejanos. El compartimento estaba tranquilo, excepto por un suave zumbido. Un caballero con un sombrero de fieltro vintage se sentó frente a ella. Tenía en sus manos un libro raro encuadernado en cuero sobre lingüística antigua.",
                    keywordsJson = """
                        [
                          {"word": "Suburbs", "meaning": "Residential areas outside a city"},
                          {"word": "Curiosity", "meaning": "Strong desire to know or learn something"},
                          {"word": "Linguistics", "meaning": "The scientific study of language and structure"}
                        ]
                    """.trimIndent(),
                    quizJson = """
                        [
                          {
                            "question": "What kind of book was the gentleman holding?",
                            "options": ["Science fiction novel", "A book about linguistics", "Travel guide book", "Cookbook"],
                            "answer": 1
                          },
                          {
                            "question": "What stayed with Sarah for the rest of her journey?",
                            "options": ["A memorable quote about words", "A small key he gave her", "A train ticket", "A drawing"],
                            "answer": 0
                          }
                        ]
                    """.trimIndent()
                ),
                LessonStory(
                    title = "The Horizon of Innovation",
                    level = "Advanced",
                    content = "To understand cutting-edge technology is to traverse an intricately woven layout of human creativity. It demands an appreciation for intellectual humility, coupled with persistent curiosity. As modern engineering leaps toward autonomous capabilities, language acts as the fundamental bridge. Natural language processing models analyze syntactic structures on a massive level, enabling artificial intelligence to converse with surprising nuance and emotional resonance. Thus, mastering a global language like English equips us to participate actively in this revolutionary frontier.",
                    translation = "Entender la tecnología de vanguardia es recorrer una intrincada malla de creatividad humana. Exige apreciar la humildad intelectual junto con una curiosidad persistente. A medida que la ingeniería moderna salta hacia capacidades autónomas, el lenguaje actúa como el puente fundamental.",
                    keywordsJson = """
                        [
                          {"word": "Traverse", "meaning": "To travel or pass across or through"},
                          {"word": "Humility", "meaning": "A modest view of one's own importance"},
                          {"word": "Resonance", "meaning": "Ability to evoke powerful images or emotions"}
                        ]
                    """.trimIndent(),
                    quizJson = """
                        [
                          {
                            "question": "What acts as the fundamental bridge for autonomous engineering?",
                            "options": ["Silicon chips", "Language", "Carbon fiber", "Financial capital"],
                            "answer": 1
                          },
                          {
                            "question": "What trait must accompany persistent curiosity according to the text?",
                            "options": ["Intellectual humility", "Physical speed", "Coding skill", "Extroversion"],
                            "answer": 0
                          }
                        ]
                    """.trimIndent()
                )
            )
            storyDao.insertStories(defaultStories)
        }
    }
}
