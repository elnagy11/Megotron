package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_progress")
data class UserProgress(
    @PrimaryKey val id: Int = 1, // Single row for player stats
    val streakCount: Int = 0,
    val lastActiveTimestamp: Long = 0L,
    val totalXp: Int = 0,
    val totalWordsLearned: Int = 0,
    val speakingSeconds: Int = 0,
    val sentencesCheckedCount: Int = 0,
    val sentencesWithoutMistakes: Int = 0,
    val badgeIdsJson: String = "[]" // JSON list of badges, e.g., ["First Chat", "Word Collector", "Streak Hero"]
)
