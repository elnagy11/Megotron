package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "lesson_stories")
data class LessonStory(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val level: String, // "Beginner" | "Intermediate" | "Advanced"
    val content: String,
    val translation: String,
    val keywordsJson: String, // JSON array of key words & meanings
    val quizJson: String, // JSON array of questions, options, and correct index
    val isCompleted: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)
