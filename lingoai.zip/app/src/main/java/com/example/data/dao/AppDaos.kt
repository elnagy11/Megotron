package com.example.data.dao

import androidx.room.*
import com.example.data.model.ChatMessage
import com.example.data.model.LessonStory
import com.example.data.model.SavedWord
import com.example.data.model.UserProgress
import kotlinx.coroutines.flow.Flow

@Dao
interface WordDao {
    @Query("SELECT * FROM saved_words ORDER BY timestamp DESC")
    fun getAllWordsFlow(): Flow<List<SavedWord>>

    @Query("SELECT * FROM saved_words WHERE isFavorite = 1 ORDER BY timestamp DESC")
    fun getFavoriteWordsFlow(): Flow<List<SavedWord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWord(word: SavedWord): Long

    @Update
    suspend fun updateWord(word: SavedWord)

    @Delete
    suspend fun deleteWord(word: SavedWord)

    @Query("DELETE FROM saved_words WHERE word = :word")
    suspend fun deleteWordByName(word: String)

    @Query("SELECT * FROM saved_words WHERE word = :word LIMIT 1")
    suspend fun getWordByName(word: String): SavedWord?
}

@Dao
interface ChatDao {
    @Query("SELECT * FROM chat_messages ORDER BY timestamp ASC")
    fun getHistoryFlow(): Flow<List<ChatMessage>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: ChatMessage): Long

    @Query("DELETE FROM chat_messages")
    suspend fun clearHistory()
}

@Dao
interface StoryDao {
    @Query("SELECT * FROM lesson_stories ORDER BY id ASC")
    fun getAllStoriesFlow(): Flow<List<LessonStory>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStory(story: LessonStory): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStories(stories: List<LessonStory>)

    @Update
    suspend fun updateStory(story: LessonStory)

    @Query("SELECT COUNT(*) FROM lesson_stories")
    suspend fun getStoryCount(): Int
}

@Dao
interface ProgressDao {
    @Query("SELECT * FROM user_progress WHERE id = 1 LIMIT 1")
    fun getProgressFlow(): Flow<UserProgress?>

    @Query("SELECT * FROM user_progress WHERE id = 1 LIMIT 1")
    suspend fun getProgressDirect(): UserProgress?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveProgress(progress: UserProgress)
}
